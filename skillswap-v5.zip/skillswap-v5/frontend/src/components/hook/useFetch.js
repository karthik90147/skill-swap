import { useState, useEffect } from 'react';

const useFetch = ({ url }) => {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => {
    if (!url) { setLoading(false); return; }
    setLoading(true);
    const token = localStorage.getItem('token');
    fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    })
      .then(r => { if (r.status === 401) throw new Error('Unauthorized'); return r.json(); })
      .then(d  => { setData(d); setError(null); })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [url]); // eslint-disable-line

  return { data, loading, error };
};

export default useFetch;
