import React from 'react';

// ── Design tokens ────────────────────────────────────────────────────────────
export const C = {
  blue:      '#3B5BDB',
  blueDark:  '#2F4AC4',
  blueLight: '#EEF2FF',
  blueMid:   '#C5D0FF',
  orange:    '#FF6B2C',
  text:      '#1A1D23',
  textMid:   '#6B7280',
  textLight: '#9CA3AF',
  bg:        '#F5F7FF',
  white:     '#FFFFFF',
  border:    '#E5E7EB',
  success:   '#10B981',
  danger:    '#EF4444',
  warn:      '#F59E0B',
};

const BADGE_COLORS = {
  Programming:'#3B5BDB', Design:'#7C3AED', Marketing:'#DB6B21',
  Music:'#9333EA', Language:'#0891B2', Finance:'#059669',
  Writing:'#D97706', Photography:'#0D9488', Cooking:'#DC2626',
  Fitness:'#65A30D', Other:'#6B7280',
};

// ── Button ───────────────────────────────────────────────────────────────────
export function Btn({ children, onClick, variant='primary', size='md', disabled, fullWidth, style }) {
  const pad = { sm:'8px 16px', md:'12px 24px', lg:'15px 32px' }[size] || '12px 24px';
  const fs  = { sm:'13px', md:'14px', lg:'16px' }[size] || '14px';
  const variants = {
    primary: { bg: C.blue,      color:'white',     border:'none' },
    outline: { bg: 'white',     color: C.blue,     border:`1.5px solid ${C.blue}` },
    ghost:   { bg: C.blueLight, color: C.blue,     border:'none' },
    danger:  { bg: C.danger,    color:'white',     border:'none' },
    success: { bg: C.success,   color:'white',     border:'none' },
    orange:  { bg: C.orange,    color:'white',     border:'none' },
    white:   { bg: 'white',     color: C.text,     border:`1.5px solid ${C.border}` },
  };
  const v = variants[variant] || variants.primary;
  return (
    <button onClick={disabled ? undefined : onClick} style={{
      padding:pad, fontSize:fs, fontWeight:'600', background:v.bg, color:v.color, border:v.border,
      borderRadius:'12px', cursor:disabled?'not-allowed':'pointer', opacity:disabled?0.5:1,
      display:'inline-flex', alignItems:'center', justifyContent:'center', gap:'6px',
      width:fullWidth?'100%':'auto', transition:'all 0.2s', fontFamily:'inherit', ...style,
    }}
      onMouseEnter={e=>{ if(!disabled) e.currentTarget.style.opacity='0.88'; }}
      onMouseLeave={e=>{ if(!disabled) e.currentTarget.style.opacity='1'; }}
    >{children}</button>
  );
}

// ── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, style, shadow=true, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: C.white, borderRadius:'16px',
      border:`1px solid ${C.border}`,
      boxShadow: shadow ? '0 2px 12px rgba(59,91,219,0.06)' : 'none',
      transition:'all 0.2s', cursor: onClick?'pointer':'default', ...style,
    }}
      onMouseEnter={e=>{ if(onClick) { e.currentTarget.style.boxShadow='0 6px 24px rgba(59,91,219,0.14)'; e.currentTarget.style.transform='translateY(-2px)'; }}}
      onMouseLeave={e=>{ if(onClick) { e.currentTarget.style.boxShadow='0 2px 12px rgba(59,91,219,0.06)'; e.currentTarget.style.transform='translateY(0)'; }}}
    >{children}</div>
  );
}

// ── Input ─────────────────────────────────────────────────────────────────────
export function Input({ value, onChange, placeholder, type='text', onKeyDown, style, icon }) {
  return (
    <div style={{ position:'relative', width:'100%' }}>
      {icon && <span style={{ position:'absolute', left:'14px', top:'50%', transform:'translateY(-50%)', color:C.textLight, display:'flex' }}>{icon}</span>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder} onKeyDown={onKeyDown}
        style={{ background:C.white, color:C.text, border:`1.5px solid ${C.border}`,
          borderRadius:'12px', padding: icon?'12px 14px 12px 40px':'12px 14px',
          fontSize:'14px', outline:'none', width:'100%', boxSizing:'border-box',
          fontFamily:'inherit', transition:'border-color 0.2s', ...style }}
        onFocus={e=>(e.target.style.borderColor=C.blue)}
        onBlur={e =>(e.target.style.borderColor=C.border)}
      />
    </div>
  );
}

// ── Select ────────────────────────────────────────────────────────────────────
export function Select({ value, onChange, children, style }) {
  return (
    <select value={value} onChange={onChange} style={{
      background:C.white, color:C.text, border:`1.5px solid ${C.border}`,
      borderRadius:'12px', padding:'12px 14px', fontSize:'14px',
      outline:'none', cursor:'pointer', width:'100%', fontFamily:'inherit', ...style,
    }}>{children}</select>
  );
}

// ── Modal ─────────────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, width='480px' }) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{ position:'fixed', inset:0, background:'rgba(26,29,35,0.5)',
      display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000, backdropFilter:'blur(4px)', padding:'16px' }}>
      <div onClick={e=>e.stopPropagation()} style={{ background:C.white, borderRadius:'20px',
        padding:'28px', maxWidth:width, width:'100%', boxShadow:'0 20px 60px rgba(59,91,219,0.15)',
        animation:'scaleIn 0.2s ease' }}>
        {title && <h3 style={{ fontWeight:'700', fontSize:'18px', color:C.text, marginBottom:'20px' }}>{title}</h3>}
        {children}
      </div>
    </div>
  );
}

// ── Spinner ───────────────────────────────────────────────────────────────────
export function Spinner({ size=32 }) {
  return <div style={{ width:size, height:size, borderRadius:'50%',
    border:`3px solid ${C.blueLight}`, borderTopColor:C.blue,
    animation:'spin 0.8s linear infinite' }} />;
}

// ── Badge / Pill ───────────────────────────────────────────────────────────────
export function Badge({ label, style }) {
  const bg = BADGE_COLORS[label] || BADGE_COLORS.Other;
  return (
    <span style={{ background:bg+'18', color:bg, border:`1px solid ${bg}30`,
      borderRadius:'9999px', padding:'3px 10px', fontSize:'12px', fontWeight:'600', ...style }}>
      {label}
    </span>
  );
}

// ── Avatar ─────────────────────────────────────────────────────────────────────
export function Avatar({ name, size=40, bg=C.blue, style }) {
  const initials = name?.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase() || '?';
  return (
    <div style={{ width:size, height:size, borderRadius:'50%', background:bg,
      display:'flex', alignItems:'center', justifyContent:'center',
      fontWeight:'700', fontSize:size*0.36+'px', color:'white', flexShrink:0, ...style }}>
      {initials}
    </div>
  );
}

// ── StatCard ───────────────────────────────────────────────────────────────────
export function StatCard({ icon, label, value, color, onClick }) {
  return (
    <Card style={{ padding:'20px', display:'flex', alignItems:'center', gap:'14px', minWidth:'150px', flex:1 }} onClick={onClick}>
      <div style={{ width:'48px', height:'48px', borderRadius:'14px',
        background:(color||C.blue)+'18', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'22px' }}>
        {icon}
      </div>
      <div>
        <p style={{ color:C.textLight, fontSize:'12px', fontWeight:'500', marginBottom:'2px' }}>{label}</p>
        <p style={{ color:C.text, fontWeight:'800', fontSize:'22px' }}>{value??'0'}</p>
      </div>
    </Card>
  );
}

// ── EmptyState ─────────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, subtitle }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center',
      justifyContent:'center', gap:'12px', padding:'60px 20px' }}>
      <span style={{ fontSize:'52px' }}>{icon}</span>
      <p style={{ fontWeight:'700', fontSize:'18px', color:C.text }}>{title}</p>
      {subtitle && <p style={{ fontSize:'14px', color:C.textMid, textAlign:'center', maxWidth:'300px', lineHeight:'1.6' }}>{subtitle}</p>}
    </div>
  );
}

// ── SectionHeader ──────────────────────────────────────────────────────────────
export function SectionHeader({ title, action, onAction }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
      <h3 style={{ fontWeight:'700', fontSize:'16px', color:C.text }}>{title}</h3>
      {action && <button onClick={onAction} style={{ background:'none', border:'none', color:C.blue,
        fontSize:'13px', fontWeight:'600', cursor:'pointer' }}>{action}</button>}
    </div>
  );
}

// ── OnlineDot ──────────────────────────────────────────────────────────────────
export function OnlineDot({ online }) {
  return <div style={{ width:'10px', height:'10px', borderRadius:'50%', border:'2px solid white',
    background: online ? C.success : C.textLight, flexShrink:0 }} />;
}
