import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Home, Search, ArrowLeftRight, MessageCircle, User, Bell, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useUser } from '../context/UserContext';
import { C, Avatar } from '../UIKit';

export default function Nav() {
  const { user_id, username, logout, token } = useAuth();
  const { setSelectedSkill, setSearchPerson, selectedSkill } = useUser();
  const navigate  = useNavigate();
  const location  = useLocation();
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs,    setNotifs]    = useState([]);
  const [unread,    setUnread]    = useState(0);
  const [skills,    setSkills]    = useState([]);
  const [menuOpen,  setMenuOpen]  = useState(false);
  const notifRef = useRef(null);

  useEffect(() => {
    fetch('/api/skills').then(r=>r.json()).then(d=>{ if(d.results) setSkills(d.results); });
  }, []);

  useEffect(() => {
    if (!token) return;
    fetch('/api/notifications/unread-count',{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>setUnread(d.count||0));
  }, [token, location.pathname]);

  useEffect(() => {
    const h = e => { if(notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false); };
    document.addEventListener('mousedown', h);
    return ()=>document.removeEventListener('mousedown', h);
  }, []);

  async function openNotifs() {
    setNotifOpen(v=>!v);
    if (!notifOpen && token) {
      const d = await fetch('/api/notifications',{ headers:{ Authorization:`Bearer ${token}` }}).then(r=>r.json());
      setNotifs(d.notifications||[]);
      fetch('/api/notifications/mark-all-read',{ method:'PUT', headers:{ Authorization:`Bearer ${token}` }});
      setUnread(0);
    }
  }

  const active = p => location.pathname === p;

  const navLinks = [
    { to:'/', icon:<Home size={20}/>, label:'Home' },
    { to:'/search', icon:<Search size={20}/>, label:'Search' },
    { to:'/req', icon:<ArrowLeftRight size={20}/>, label:'Exchange' },
    { to:'/chat', icon:<MessageCircle size={20}/>, label:'Chat' },
    { to:'/profile', icon:<User size={20}/>, label:'Profile' },
  ];

  return (
    <>
      {/* Top Nav */}
      <nav style={{ background:C.white, borderBottom:`1px solid ${C.border}`,
        display:'flex', alignItems:'center', justifyContent:'space-between',
        padding:'0 24px', height:'64px', position:'sticky', top:0, zIndex:100,
        boxShadow:'0 1px 8px rgba(59,91,219,0.06)' }}>

        {/* Logo */}
        <Link to="/" style={{ textDecoration:'none', display:'flex', alignItems:'center', gap:'10px' }}>
          <div style={{ width:'36px', height:'36px', borderRadius:'10px',
            background:`linear-gradient(135deg,${C.blue},#5B7FE8)`,
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px' }}>🔄</div>
          <div>
            <span style={{ fontWeight:'800', fontSize:'16px', color:C.blue }}>Skill</span>
            <span style={{ fontWeight:'800', fontSize:'16px', color:C.text }}>Exchange</span>
          </div>
        </Link>

        {/* Desktop search + filter */}
        <div className="top-nav-links" style={{ display:'flex', gap:'8px', alignItems:'center' }}>
          <div style={{ position:'relative' }}>
            <Search size={15} style={{ position:'absolute', left:'12px', top:'50%', transform:'translateY(-50%)', color:C.textLight }} />
            <input placeholder="Search for skills or people…" onChange={e=>setSearchPerson(e.target.value)}
              style={{ background:C.bg, border:`1.5px solid ${C.border}`, borderRadius:'10px',
                padding:'9px 14px 9px 34px', fontSize:'13px', outline:'none', width:'220px', fontFamily:'inherit' }}
              onFocus={e=>e.target.style.borderColor=C.blue}
              onBlur={e=>e.target.style.borderColor=C.border} />
          </div>
          <select value={selectedSkill} onChange={e=>setSelectedSkill(e.target.value)}
            style={{ background:C.bg, border:`1.5px solid ${C.border}`, borderRadius:'10px',
              padding:'9px 12px', fontSize:'13px', outline:'none', cursor:'pointer', fontFamily:'inherit' }}>
            <option value="">All Skills</option>
            {skills.map(s=><option key={s.skill_id} value={s.name}>{s.name}</option>)}
          </select>
        </div>

        {/* Desktop nav links */}
        <div className="top-nav-links" style={{ display:'flex', alignItems:'center', gap:'4px' }}>
          {navLinks.map(({to,label})=>(
            <Link key={to} to={to} style={{ textDecoration:'none', padding:'8px 14px', borderRadius:'10px',
              fontWeight:'600', fontSize:'14px', transition:'all 0.2s',
              color: active(to) ? C.blue : C.textMid,
              background: active(to) ? C.blueLight : 'transparent' }}>
              {label}
            </Link>
          ))}

          {/* Notification bell */}
          {user_id && (
            <div style={{ position:'relative' }} ref={notifRef}>
              <button onClick={openNotifs} style={{ background:notifOpen?C.blueLight:'transparent',
                border:'none', cursor:'pointer', borderRadius:'10px', padding:'8px 10px',
                display:'flex', alignItems:'center', position:'relative' }}>
                <Bell size={20} color={notifOpen?C.blue:C.textMid} />
                {unread>0 && <span style={{ position:'absolute', top:'4px', right:'6px',
                  background:C.danger, color:'white', borderRadius:'99px',
                  fontSize:'10px', fontWeight:'700', padding:'1px 5px', minWidth:'16px', textAlign:'center' }}>{unread}</span>}
              </button>
              {notifOpen && (
                <div style={{ position:'absolute', right:0, top:'50px', background:C.white,
                  border:`1px solid ${C.border}`, borderRadius:'16px', width:'310px',
                  boxShadow:'0 8px 32px rgba(59,91,219,0.12)', maxHeight:'380px', overflowY:'auto', zIndex:200 }}>
                  <div style={{ padding:'16px', borderBottom:`1px solid ${C.border}`, fontWeight:'700', color:C.text }}>Notifications</div>
                  {notifs.length===0
                    ? <p style={{ padding:'24px', textAlign:'center', color:C.textLight, fontSize:'13px' }}>No notifications yet</p>
                    : notifs.map((n,i)=>(
                      <div key={i} style={{ padding:'12px 16px', borderBottom:`1px solid ${C.border}`,
                        background:n.read?C.white:C.blueLight+'80', display:'flex', gap:'10px', alignItems:'flex-start' }}>
                        <span style={{ fontSize:'18px' }}>{n.type==='request_received'?'📨':n.type==='request_accepted'?'✅':n.type==='learn_together'?'📚':'❌'}</span>
                        <div>
                          <p style={{ color:C.text, fontSize:'13px', lineHeight:'1.4' }}>{n.message}</p>
                          <p style={{ color:C.textLight, fontSize:'11px', marginTop:'3px' }}>{new Date(n.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}

          {/* Avatar + logout */}
          {user_id && (
            <div style={{ display:'flex', alignItems:'center', gap:'8px', marginLeft:'8px' }}>
              <Avatar name={username} size={36} />
              <button onClick={()=>{ logout(); navigate('/auth'); }} style={{ background:'none', border:'none',
                color:C.textMid, cursor:'pointer', display:'flex', alignItems:'center', gap:'4px', fontSize:'13px', fontWeight:'600' }}>
                <LogOut size={15}/> Logout
              </button>
            </div>
          )}

          {!user_id && (
            <button onClick={()=>navigate('/auth')} style={{ background:C.blue, color:'white', border:'none',
              borderRadius:'10px', padding:'8px 18px', cursor:'pointer', fontWeight:'600', fontSize:'14px' }}>
              Login
            </button>
          )}
        </div>

        {/* Mobile hamburger */}
        <button onClick={()=>setMenuOpen(v=>!v)} style={{ background:'none', border:'none', cursor:'pointer', display:'none' }} className="mobile-menu-btn">
          {menuOpen ? <X size={24} color={C.text}/> : <Menu size={24} color={C.text}/>}
        </button>
      </nav>

      {/* Mobile dropdown */}
      {menuOpen && (
        <div style={{ position:'fixed', top:'64px', left:0, right:0, background:C.white,
          borderBottom:`1px solid ${C.border}`, padding:'16px', zIndex:99,
          display:'flex', flexDirection:'column', gap:'4px', boxShadow:'0 8px 24px rgba(0,0,0,0.08)' }}>
          {navLinks.map(({to,icon,label})=>(
            <Link key={to} to={to} onClick={()=>setMenuOpen(false)} style={{ textDecoration:'none',
              display:'flex', alignItems:'center', gap:'12px', padding:'12px 16px', borderRadius:'12px',
              color:active(to)?C.blue:C.text, background:active(to)?C.blueLight:'transparent', fontWeight:'600' }}>
              {icon}{label}
            </Link>
          ))}
        </div>
      )}

      {/* Bottom mobile nav */}
      <div className="bottom-nav" style={{ position:'fixed', bottom:0, left:0, right:0, background:C.white,
        borderTop:`1px solid ${C.border}`, display:'flex', justifyContent:'space-around',
        padding:'8px 0 16px', zIndex:100, boxShadow:'0 -4px 16px rgba(59,91,219,0.06)' }}>
        {navLinks.map(({to,icon,label})=>(
          <Link key={to} to={to} style={{ textDecoration:'none', display:'flex', flexDirection:'column',
            alignItems:'center', gap:'3px', padding:'4px 12px' }}>
            <div style={{ color:active(to)?C.blue:C.textLight, transition:'color 0.2s' }}>{icon}</div>
            <span style={{ fontSize:'10px', fontWeight:'600', color:active(to)?C.blue:C.textLight }}>{label}</span>
          </Link>
        ))}
      </div>
    </>
  );
}
