import React, { useState } from 'react';
import Login from './Login';
import Signup from './Signup';
import { C } from '../UIKit';

export default function Auth() {
  const [showLogin, setShowLogin] = useState(true);
  return (
    <div style={{ minHeight:'100vh', display:'flex', background:C.white }}>
      {/* Left panel - decorative */}
      <div style={{ flex:1, background:`linear-gradient(135deg, ${C.blue} 0%, #5B7FE8 100%)`,
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
        padding:'48px', minHeight:'100vh' }} className="auth-left">
        <div style={{ textAlign:'center', color:'white', maxWidth:'380px' }}>
          <div style={{ width:'72px', height:'72px', borderRadius:'20px', background:'rgba(255,255,255,0.2)',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:'32px', margin:'0 auto 24px' }}>🔄</div>
          <h1 style={{ fontWeight:'800', fontSize:'36px', marginBottom:'16px' }}>SkillSwap</h1>
          <p style={{ fontSize:'16px', opacity:0.85, lineHeight:'1.7' }}>
            Connect · Collaborate · Grow<br/>
            Exchange skills with people around you and build meaningful connections.
          </p>
          <div style={{ display:'flex', gap:'16px', justifyContent:'center', marginTop:'40px', flexWrap:'wrap' }}>
            {['📚 Learn','🎯 Teach','🤝 Connect','⭐ Grow'].map(t=>(
              <span key={t} style={{ background:'rgba(255,255,255,0.15)', borderRadius:'9999px',
                padding:'8px 16px', fontSize:'13px', fontWeight:'600' }}>{t}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel - form */}
      <div style={{ width:'480px', display:'flex', flexDirection:'column', alignItems:'center',
        justifyContent:'center', padding:'48px 40px', overflowY:'auto' }}>
        <div style={{ width:'100%', maxWidth:'380px' }}>
          <h2 style={{ fontWeight:'800', fontSize:'28px', color:C.text, marginBottom:'8px' }}>
            {showLogin ? 'Welcome back!' : 'Create Account'}
          </h2>
          <p style={{ color:C.textMid, fontSize:'14px', marginBottom:'32px' }}>
            {showLogin ? "Hi, we've been missing you." : 'Fill your information below to register.'}
          </p>
          {showLogin ? <Login /> : <Signup />}
          <p style={{ textAlign:'center', marginTop:'24px', fontSize:'14px', color:C.textMid }}>
            {showLogin ? "Don't have an account? " : 'Already have an account? '}
            <button onClick={()=>setShowLogin(!showLogin)} style={{ background:'none', border:'none',
              color:C.blue, fontWeight:'600', cursor:'pointer', fontSize:'14px' }}>
              {showLogin ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
