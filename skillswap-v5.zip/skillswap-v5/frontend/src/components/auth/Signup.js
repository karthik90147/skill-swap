import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Btn, Input, C } from '../UIKit';
import { User, Mail, Lock } from 'lucide-react';
import Errorpop from '../Errorpop/Errorpop';

export default function Signup() {
  const [form, setForm]       = useState({ username:'', email:'', password:'' });
  const [agreed, setAgreed]   = useState(false);
  const [err, setErr]         = useState(false);
  const [errMsg, setErrMsg]   = useState('');
  const [loading, setLoading] = useState(false);
  const { setAuth } = useAuth();
  const navigate    = useNavigate();

  async function handle() {
    if (!form.username||!form.email||!form.password) { setErrMsg('Please fill all fields'); setErr(true); return; }
    if (!agreed) { setErrMsg('Please agree to Terms & Conditions'); setErr(true); return; }
    setLoading(true);
    try {
      const res  = await fetch('/api/auth/signup', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
      const data = await res.json();
      if (data.error) { setErrMsg(data.error); setErr(true); }
      else { setAuth({ user_id:data.user_id, username:data.username, token:data.token }); navigate('/onboarding'); }
    } catch { setErrMsg('Cannot connect to backend.'); setErr(true); }
    finally { setLoading(false); }
  }

  return (
    <>
      <Errorpop err={errMsg} open={err} changencomponent={setErr} />
      <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
        <div>
          <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Name</label>
          <Input placeholder="Username" value={form.username} icon={<User size={16}/>}
            onChange={e=>setForm({...form,username:e.target.value})} onKeyDown={e=>e.key==='Enter'&&handle()} />
        </div>
        <div>
          <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Email</label>
          <Input type="email" placeholder="example@gmail.com" value={form.email} icon={<Mail size={16}/>}
            onChange={e=>setForm({...form,email:e.target.value})} onKeyDown={e=>e.key==='Enter'&&handle()} />
        </div>
        <div>
          <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Password</label>
          <Input type="password" placeholder="••••••••" value={form.password} icon={<Lock size={16}/>}
            onChange={e=>setForm({...form,password:e.target.value})} onKeyDown={e=>e.key==='Enter'&&handle()} />
        </div>
        <label style={{ display:'flex', alignItems:'center', gap:'10px', cursor:'pointer' }}>
          <input type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)}
            style={{ width:'16px', height:'16px', accentColor:C.blue }} />
          <span style={{ fontSize:'13px', color:C.textMid }}>
            Agree with <span style={{ color:C.blue, fontWeight:'600' }}>Terms & Conditions</span>
          </span>
        </label>
        <Btn onClick={handle} disabled={loading} fullWidth style={{ marginTop:'4px', padding:'14px' }}>
          {loading ? 'Creating account…' : 'Sign Up'}
        </Btn>
      </div>
    </>
  );
}
