import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Btn, Input, C } from '../UIKit';
import { Mail, Lock } from 'lucide-react';
import Errorpop from '../Errorpop/Errorpop';

export default function Login() {
  const [form, setForm]       = useState({ emailOrUsername:'', password:'' });
  const [err, setErr]         = useState(false);
  const [errMsg, setErrMsg]   = useState('');
  const [loading, setLoading] = useState(false);
  const { setAuth } = useAuth();
  const navigate    = useNavigate();

  async function handle() {
    if (!form.emailOrUsername || !form.password) { setErrMsg('Please fill all fields'); setErr(true); return; }
    setLoading(true);
    try {
      const res  = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
      const data = await res.json();
      if (data.isCorrectPassword) {
        setAuth({ user_id:data.user_id, username:data.username, token:data.token });
        navigate('/onboarding');
      } else { setErrMsg(data.error||'Invalid credentials'); setErr(true); }
    } catch { setErrMsg('Cannot connect to backend.'); setErr(true); }
    finally { setLoading(false); }
  }

  return (
    <>
      <Errorpop err={errMsg} open={err} changencomponent={setErr} />
      <div style={{ display:'flex', flexDirection:'column', gap:'16px' }}>
        <div>
          <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Email</label>
          <Input placeholder="example@gmail.com" value={form.emailOrUsername} type="email"
            icon={<Mail size={16}/>}
            onChange={e=>setForm({...form,emailOrUsername:e.target.value})}
            onKeyDown={e=>e.key==='Enter'&&handle()} />
        </div>
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'6px' }}>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text }}>Password</label>
            <button style={{ background:'none', border:'none', color:C.blue, fontSize:'12px', cursor:'pointer' }}>Forgot password?</button>
          </div>
          <Input type="password" placeholder="••••••••" value={form.password}
            icon={<Lock size={16}/>}
            onChange={e=>setForm({...form,password:e.target.value})}
            onKeyDown={e=>e.key==='Enter'&&handle()} />
        </div>
        <Btn onClick={handle} disabled={loading} fullWidth style={{ marginTop:'8px', padding:'14px' }}>
          {loading ? 'Logging in…' : 'Log In'}
        </Btn>
      </div>
    </>
  );
}
