import { createContext, useContext, useState } from 'react';

export const AuthContext = createContext({});

export function AuthProvider({ children }) {
  const [auth, setAuthState] = useState({
    user_id:  localStorage.getItem('user_id')  || '',
    username: localStorage.getItem('username') || '',
    token:    localStorage.getItem('token')    || '',
  });

  const setAuth = ({ user_id, username, token }) => {
    localStorage.setItem('user_id',  user_id);
    localStorage.setItem('username', username);
    localStorage.setItem('token',    token);
    setAuthState({ user_id, username, token });
  };

  const logout = () => {
    ['user_id','username','token'].forEach(k => localStorage.removeItem(k));
    setAuthState({ user_id:'', username:'', token:'' });
  };

  return (
    <AuthContext.Provider value={{ ...auth, setAuth, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
