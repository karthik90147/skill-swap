import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext({ socket: null, onlineUsers: [] });

export function SocketProvider({ children }) {
  const { token, user_id } = useAuth();
  // KEY FIX: store socket in STATE (not ref) so context re-renders when socket connects
  const [socket, setSocket]           = useState(null);
  const [onlineUsers, setOnlineUsers] = useState([]);

  useEffect(() => {
    if (!token || !user_id) return;

    const s = io('http://localhost:5000', {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    s.on('connect', () => {
      console.log('✅ Socket connected:', s.id);
      setSocket(s);  // set AFTER connected so it's ready to use
    });

    s.on('online_users', (users) => setOnlineUsers(users));

    s.on('connect_error', (err) => {
      console.error('❌ Socket error:', err.message);
    });

    s.on('disconnect', () => {
      console.log('🔌 Socket disconnected');
      setSocket(null);
    });

    return () => {
      s.disconnect();
      setSocket(null);
    };
  }, [token, user_id]);

  return (
    <SocketContext.Provider value={{ socket, onlineUsers }}>
      {children}
    </SocketContext.Provider>
  );
}

export const useSocket = () => useContext(SocketContext);
