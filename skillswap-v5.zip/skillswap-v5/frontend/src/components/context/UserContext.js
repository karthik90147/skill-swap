import { createContext, useContext, useState } from 'react';

export const UserContext = createContext({});

export function UserProvider({ children }) {
  const [persons, setPersons]               = useState([]);
  const [selectedSkill, setSelectedSkill]   = useState('');
  const [searchPerson,  setSearchPerson]    = useState('');

  const filterPersons = persons.filter(p => {
    const s = selectedSkill ? p.skill_name?.toLowerCase().includes(selectedSkill.toLowerCase()) : true;
    const n = searchPerson  ? p.username?.toLowerCase().includes(searchPerson.toLowerCase())    : true;
    return s && n;
  });

  return (
    <UserContext.Provider value={{ persons, filterPersons, selectedSkill, searchPerson, setPersons, setSelectedSkill, setSearchPerson }}>
      {children}
    </UserContext.Provider>
  );
}

export const useUser = () => useContext(UserContext);
