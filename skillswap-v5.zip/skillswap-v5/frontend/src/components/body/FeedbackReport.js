import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { C, Btn, Card, Input } from '../UIKit';

const EMOJIS   = ['😡','😞','😐','😊','😍'];
const REPORTS  = ['Inappropriate behavior/language','Misrepresentation','Spam or irrelevant content','Safety concerns','Unprofessional conduct','Technical issue','Violation of community guidelines','Other'];

export default function FeedbackReport({ targetId, targetName, onClose, mode='feedback' }) {
  const { token } = useAuth();
  const [view, setView]       = useState(mode);
  const [rating, setRating]   = useState(0);
  const [comment, setComment] = useState('');
  const [hovered, setHovered] = useState(0);
  const [reason, setReason]   = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submitFeedback() {
    if (!rating) { alert('Please select a rating'); return; }
    setLoading(true);
    try {
      await fetch('/api/feedback',{ method:'POST',
        headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
        body:JSON.stringify({ to:targetId, rating, comment, emoji:EMOJIS[rating-1] }) });
      setSubmitted(true);
    } catch { alert('Failed to submit'); }
    finally { setLoading(false); }
  }

  async function submitReport() {
    if (!reason) { alert('Please select a reason'); return; }
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:'20px', padding:'32px' }}>
        <div style={{ width:'80px', height:'80px', borderRadius:'50%', background:C.blueLight,
          display:'flex', alignItems:'center', justifyContent:'center', fontSize:'36px' }}>✓</div>
        <h3 style={{ fontWeight:'700', fontSize:'20px', color:C.text }}>Submitted!</h3>
        <p style={{ color:C.textMid, textAlign:'center', fontSize:'14px', lineHeight:'1.6' }}>
          {view==='feedback'
            ? 'Thank you for your feedback! It helps us improve the experience for everyone.'
            : 'Thank you for your report. We\'ll review it to ensure high quality interactions.'}
        </p>
        <Btn onClick={onClose} fullWidth>Done</Btn>
      </div>
    );
  }

  return (
    <div>
      {/* Tabs */}
      <div style={{ display:'flex', gap:'4px', marginBottom:'24px', background:C.bg, borderRadius:'12px', padding:'4px' }}>
        {['feedback','report'].map(v=>(
          <button key={v} onClick={()=>setView(v)} style={{
            flex:1, padding:'8px', border:'none', borderRadius:'8px', fontWeight:'600',
            fontSize:'13px', cursor:'pointer', fontFamily:'inherit',
            background:view===v?C.blue:'transparent', color:view===v?'white':C.textMid }}>
            {v==='feedback'?'Feedback':'Report'}
          </button>
        ))}
      </div>

      {view==='feedback' ? (
        <div style={{ display:'flex', flexDirection:'column', gap:'20px' }}>
          <div style={{ textAlign:'center', padding:'20px', background:`linear-gradient(135deg,${C.blue},#5B7FE8)`, borderRadius:'16px', color:'white' }}>
            <p style={{ fontWeight:'700', fontSize:'16px', marginBottom:'4px' }}>How would you rate your experience?</p>
            <p style={{ fontSize:'13px', opacity:0.8 }}>with {targetName}</p>
          </div>
          {/* Emoji rating */}
          <div style={{ display:'flex', justifyContent:'center', gap:'12px' }}>
            {EMOJIS.map((e,i)=>(
              <button key={i} onClick={()=>setRating(i+1)} onMouseEnter={()=>setHovered(i+1)} onMouseLeave={()=>setHovered(0)}
                style={{ background:'none', border:'none', cursor:'pointer', fontSize:'36px', transition:'transform 0.15s',
                  transform: (hovered===i+1||rating===i+1)?'scale(1.3)':'scale(1)',
                  filter: rating===i+1?'none':'grayscale(30%)' }}>
                {e}
              </button>
            ))}
          </div>
          {rating>0 && <p style={{ textAlign:'center', fontWeight:'600', color:C.blue, fontSize:'14px' }}>
            {['Poor','Fair','Good','Great','Excellent'][rating-1]}
          </p>}
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.textMid, marginBottom:'8px', display:'block' }}>Write your comment (optional)</label>
            <textarea value={comment} onChange={e=>setComment(e.target.value)}
              placeholder="Describe here your personal experience about the skill exchange"
              rows={4} style={{ width:'100%', border:`1.5px solid ${C.border}`, borderRadius:'12px',
                padding:'12px 14px', fontSize:'14px', outline:'none', fontFamily:'inherit', resize:'none',
                lineHeight:'1.5' }}
              onFocus={e=>e.target.style.borderColor=C.blue}
              onBlur={e=>e.target.style.borderColor=C.border} />
          </div>
          <Btn onClick={submitFeedback} disabled={!rating||loading} fullWidth style={{ padding:'14px' }}>
            {loading?'Submitting…':'Submit'}
          </Btn>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:'16px' }}>
          <p style={{ fontWeight:'700', color:C.text, fontSize:'15px' }}>What is the reason for reporting this user?</p>
          {REPORTS.map(r=>(
            <label key={r} style={{ display:'flex', alignItems:'center', gap:'10px', cursor:'pointer', padding:'4px 0' }}>
              <input type="radio" name="report" value={r} checked={reason===r} onChange={()=>setReason(r)}
                style={{ accentColor:C.blue, width:'16px', height:'16px' }} />
              <span style={{ fontSize:'14px', color:C.text }}>{r}</span>
            </label>
          ))}
          <Btn onClick={submitReport} disabled={!reason} fullWidth style={{ padding:'14px' }}>Report</Btn>
        </div>
      )}
    </div>
  );
}
