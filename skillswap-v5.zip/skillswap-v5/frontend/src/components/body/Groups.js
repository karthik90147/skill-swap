import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { C, Card, Btn, Input, Select, Modal, Avatar, EmptyState, SectionHeader } from '../UIKit';
import Loader from '../Loader/Loader';
import { Plus, Users, Search } from 'lucide-react';

const CATS = ['Programming','Design','Marketing','Music','Language','Finance','Writing','Photography','Cooking','Fitness','Other'];

export default function Groups() {
  const { token, user_id } = useAuth();
  const [groups, setGroups]         = useState([]);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [newGroup, setNewGroup]     = useState({ name:'', description:'', category:'Other' });
  const [creating, setCreating]     = useState(false);
  const [joined, setJoined]         = useState(new Set());

  useEffect(() => {
    fetch('/api/groups',{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>{
        setGroups(d.groups||[]);
        const myGroups = new Set((d.groups||[]).filter(g=>g.members?.some(m=>m._id?.toString()===user_id?.toString())).map(g=>g._id));
        setJoined(myGroups);
        setLoading(false);
      }).catch(()=>setLoading(false));
  }, [token, user_id]);

  async function createGroup() {
    if (!newGroup.name.trim()) return;
    setCreating(true);
    try {
      const res  = await fetch('/api/groups',{ method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`}, body:JSON.stringify(newGroup) });
      const data = await res.json();
      if (data.group) { setGroups(p=>[data.group,...p]); setJoined(p=>new Set([...p,data.group._id])); setCreateOpen(false); setNewGroup({ name:'',description:'',category:'Other' }); }
    } catch { alert('Failed to create group'); }
    finally { setCreating(false); }
  }

  async function toggleJoin(groupId) {
    const isJoined = joined.has(groupId);
    try {
      await fetch(`/api/groups/${groupId}/${isJoined?'leave':'join'}`,{ method:'POST', headers:{ Authorization:`Bearer ${token}` }});
      setJoined(p=>{ const n=new Set(p); isJoined?n.delete(groupId):n.add(groupId); return n; });
      setGroups(p=>p.map(g=>g._id===groupId ? { ...g, members: isJoined ? g.members.filter(m=>m._id?.toString()!==user_id?.toString()) : [...(g.members||[]),{ _id:user_id }] } : g));
    } catch { alert('Failed'); }
  }

  const filtered = groups.filter(g=>g.name?.toLowerCase().includes(search.toLowerCase()));
  const COLORS = [C.blue,'#7C3AED','#0891B2',C.success,C.warn,'#DB2777'];

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'800px', margin:'0 auto' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' }}>
          <div>
            <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text }}>Groups</h2>
            <p style={{ color:C.textMid, fontSize:'13px', marginTop:'2px' }}>Join skill communities</p>
          </div>
          <Btn onClick={()=>setCreateOpen(true)} size="sm"><Plus size={14}/>Create group</Btn>
        </div>

        {/* Search */}
        <div style={{ marginBottom:'20px' }}>
          <Input placeholder="Search groups…" value={search} onChange={e=>setSearch(e.target.value)}
            icon={<Search size={16}/>} />
        </div>

        {/* Groups list */}
        {loading ? <Loader fullPage /> : filtered.length===0 ? (
          <EmptyState icon="👥" title="No groups yet" subtitle="Create the first group and invite others!" />
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
            {filtered.map((g,i)=>{
              const isMember = joined.has(g._id);
              const memberCount = g.members?.length||0;
              const color = COLORS[i%COLORS.length];
              return (
                <Card key={g._id} style={{ padding:'20px', display:'flex', gap:'16px', alignItems:'center' }}>
                  {/* Group avatar */}
                  <div style={{ width:'52px', height:'52px', borderRadius:'14px', background:color+'18',
                    display:'flex', alignItems:'center', justifyContent:'center', fontSize:'22px', flexShrink:0 }}>
                    {['💻','🎨','📱','🎵','📸','🍳'][i%6]}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontWeight:'700', color:C.text, fontSize:'15px', marginBottom:'3px' }}>{g.name}</p>
                    <p style={{ color:C.textMid, fontSize:'12px', lineHeight:'1.5',
                      overflow:'hidden', textOverflow:'ellipsis', display:'-webkit-box',
                      WebkitLineClamp:2, WebkitBoxOrient:'vertical' }}>
                      {g.description || 'A community to share and learn together.'}
                    </p>
                    <div style={{ display:'flex', alignItems:'center', gap:'4px', marginTop:'6px' }}>
                      <Users size={12} color={C.textLight} />
                      <span style={{ fontSize:'12px', color:C.textMid }}>{memberCount} members</span>
                    </div>
                  </div>
                  <Btn onClick={()=>toggleJoin(g._id)} variant={isMember?'white':'primary'} size="sm"
                    style={{ flexShrink:0, minWidth:'90px' }}>
                    {isMember ? 'Leave' : 'Ask to Join'}
                  </Btn>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Create group modal */}
      <Modal open={createOpen} onClose={()=>setCreateOpen(false)} title="Create New Group">
        <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Group Name</label>
            <Input placeholder="e.g. React Developers" value={newGroup.name} onChange={e=>setNewGroup({...newGroup,name:e.target.value})} />
          </div>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Description</label>
            <textarea value={newGroup.description} onChange={e=>setNewGroup({...newGroup,description:e.target.value})}
              placeholder="What is this group about?" rows={3}
              style={{ width:'100%', border:`1.5px solid ${C.border}`, borderRadius:'12px',
                padding:'12px 14px', fontSize:'14px', outline:'none', fontFamily:'inherit', resize:'none' }}
              onFocus={e=>e.target.style.borderColor=C.blue}
              onBlur={e=>e.target.style.borderColor=C.border} />
          </div>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Category</label>
            <Select value={newGroup.category} onChange={e=>setNewGroup({...newGroup,category:e.target.value})}>
              {CATS.map(c=><option key={c} value={c}>{c}</option>)}
            </Select>
          </div>
          <div style={{ display:'flex', gap:'8px', marginTop:'4px' }}>
            <Btn onClick={createGroup} disabled={creating||!newGroup.name.trim()} fullWidth>
              {creating?'Creating…':'Create Group'}
            </Btn>
            <Btn onClick={()=>setCreateOpen(false)} variant="white" fullWidth>Cancel</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
