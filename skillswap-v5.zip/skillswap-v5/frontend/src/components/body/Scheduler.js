import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { C, Card, Btn, Input, Select, Modal, Avatar, EmptyState } from '../UIKit';
import Loader from '../Loader/Loader';
import { Plus, Calendar, Clock } from 'lucide-react';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAYS_SHORT = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

function MiniCalendar({ selected, onSelect }) {
  const [viewDate, setViewDate] = useState(new Date());
  const year  = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const offset = firstDay===0 ? 6 : firstDay-1;
  const cells = Array(offset).fill(null).concat(Array.from({length:daysInMonth},(_,i)=>i+1));

  return (
    <div style={{ background:C.white, borderRadius:'16px', border:`1px solid ${C.border}`, padding:'16px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'12px' }}>
        <button onClick={()=>setViewDate(new Date(year,month-1,1))} style={{ background:'none',border:'none',cursor:'pointer',color:C.textMid,fontSize:'18px' }}>‹</button>
        <p style={{ fontWeight:'700', fontSize:'15px', color:C.text }}>{MONTHS[month]} {year}</p>
        <button onClick={()=>setViewDate(new Date(year,month+1,1))} style={{ background:'none',border:'none',cursor:'pointer',color:C.textMid,fontSize:'18px' }}>›</button>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:'2px', marginBottom:'8px' }}>
        {DAYS_SHORT.map(d=><div key={d} style={{ textAlign:'center', fontSize:'11px', fontWeight:'600', color:C.textMid, padding:'4px' }}>{d}</div>)}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:'2px' }}>
        {cells.map((d,i)=>{
          if (!d) return <div key={i}/>;
          const dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
          const isSelected = selected===dateStr;
          const isToday = new Date().toDateString()===new Date(year,month,d).toDateString();
          return (
            <button key={i} onClick={()=>onSelect(dateStr)} style={{
              background: isSelected?C.blue:isToday?C.blueLight:'transparent',
              color: isSelected?'white':isToday?C.blue:C.text,
              border:'none', borderRadius:'8px', padding:'6px 2px', fontSize:'13px',
              fontWeight:isSelected||isToday?'700':'400', cursor:'pointer', transition:'all 0.15s',
            }}>{d}</button>
          );
        })}
      </div>
    </div>
  );
}

export default function Scheduler() {
  const { token, user_id } = useAuth();
  const [sessions, setSessions]     = useState([]);
  const [loading, setLoading]       = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm]             = useState({ participant_id:'', title:'', skill:'', date:'', startTime:'09:00', endTime:'10:00', notes:'' });
  const [friends, setFriends]       = useState([]);
  const [creating, setCreating]     = useState(false);
  const [tab, setTab]               = useState('all');

  useEffect(() => {
    fetch('/api/sessions',{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>{ setSessions(d.sessions||[]); setLoading(false); }).catch(()=>setLoading(false));
    fetch(`/api/requests/friends/${user_id}`,{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>setFriends(d.results||[]));
  }, [token, user_id]);

  async function createSession() {
    if (!form.title||!form.date||!form.startTime||!form.endTime||!form.participant_id) { alert('Fill all required fields'); return; }
    setCreating(true);
    try {
      const res  = await fetch('/api/sessions',{ method:'POST', headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`}, body:JSON.stringify(form) });
      const data = await res.json();
      if (data.session) { setSessions(p=>[data.session,...p]); setCreateOpen(false); setForm({ participant_id:'',title:'',skill:'',date:'',startTime:'09:00',endTime:'10:00',notes:'' }); }
      else alert(data.error);
    } catch { alert('Failed to create session'); }
    finally { setCreating(false); }
  }

  const now     = new Date();
  const filtered = sessions.filter(s=>{ if(tab==='today') return new Date(s.date).toDateString()===now.toDateString(); if(tab==='week') { const d=new Date(s.date); return d>=now && d<=new Date(now.getTime()+7*86400000); } return true; });

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'700px', margin:'0 auto' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' }}>
          <div>
            <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text }}>Session Scheduler</h2>
            <p style={{ color:C.textMid, fontSize:'13px', marginTop:'2px' }}>Schedule your skill exchange sessions</p>
          </div>
          <Btn onClick={()=>setCreateOpen(true)} size="sm"><Plus size={14}/>New Session</Btn>
        </div>

        {/* Calendar */}
        <div style={{ marginBottom:'20px' }}>
          <MiniCalendar selected={form.date} onSelect={d=>setForm(f=>({...f,date:d}))} />
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', background:C.white, borderRadius:'12px', padding:'4px', marginBottom:'20px', border:`1px solid ${C.border}` }}>
          {[['all','All'],['today','Today'],['week','This week'],['month','This month']].map(([key,label])=>(
            <button key={key} onClick={()=>setTab(key)} style={{
              flex:1, padding:'8px', border:'none', borderRadius:'8px', fontWeight:'600', fontSize:'12px',
              cursor:'pointer', transition:'all 0.2s', fontFamily:'inherit',
              background:tab===key?C.blue:'transparent', color:tab===key?'white':C.textMid,
            }}>{label}</button>
          ))}
        </div>

        {/* Sessions list */}
        {loading ? <Loader /> : filtered.length===0 ? (
          <EmptyState icon="📅" title="No sessions scheduled" subtitle="Schedule a skill exchange session with your friends!" />
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
            {filtered.map((s,i)=>{
              const isHost = s.host?._id?.toString()===user_id?.toString();
              const partner = isHost ? s.participant : s.host;
              const d = new Date(s.date);
              return (
                <Card key={s._id} style={{ padding:'16px', display:'flex', gap:'14px', alignItems:'center' }}>
                  <div style={{ width:'48px', height:'48px', borderRadius:'12px', background:C.blueLight,
                    display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                    <span style={{ fontSize:'16px', fontWeight:'800', color:C.blue }}>{d.getDate()}</span>
                    <span style={{ fontSize:'10px', color:C.blue, fontWeight:'600' }}>{MONTHS[d.getMonth()].slice(0,3)}</span>
                  </div>
                  <div style={{ flex:1 }}>
                    <p style={{ fontWeight:'700', color:C.text, marginBottom:'3px' }}>{s.title}</p>
                    <div style={{ display:'flex', gap:'12px', fontSize:'12px', color:C.textMid }}>
                      <span style={{ display:'flex', alignItems:'center', gap:'3px' }}><Clock size={11}/>{s.startTime} – {s.endTime}</span>
                      <span>with {partner?.username||'—'}</span>
                    </div>
                    {s.skill && <span style={{ fontSize:'11px', color:C.blue, fontWeight:'600' }}>{s.skill}</span>}
                  </div>
                  <span style={{ fontSize:'11px', fontWeight:'700', padding:'4px 10px', borderRadius:'9999px',
                    background: s.status==='scheduled'?C.blueLight:s.status==='completed'?C.success+'18':C.danger+'18',
                    color: s.status==='scheduled'?C.blue:s.status==='completed'?C.success:C.danger }}>
                    {s.status}
                  </span>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Create modal */}
      <Modal open={createOpen} onClose={()=>setCreateOpen(false)} title="📅 Schedule New Session">
        <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>With (Friend)</label>
            <Select value={form.participant_id} onChange={e=>setForm({...form,participant_id:e.target.value})}>
              <option value="">Select a friend…</option>
              {friends.map(f=><option key={f.requester_id} value={f.requester_id}>{f.requester_name}</option>)}
            </Select>
          </div>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Title</label>
            <Input placeholder="e.g. Guitar lesson with Karthik" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} />
          </div>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Skill</label>
            <Input placeholder="e.g. React, Guitar…" value={form.skill} onChange={e=>setForm({...form,skill:e.target.value})} />
          </div>
          <div>
            <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Date</label>
            <Input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} />
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'10px' }}>
            <div>
              <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>Start</label>
              <Input type="time" value={form.startTime} onChange={e=>setForm({...form,startTime:e.target.value})} />
            </div>
            <div>
              <label style={{ fontSize:'13px', fontWeight:'600', color:C.text, marginBottom:'6px', display:'block' }}>End</label>
              <Input type="time" value={form.endTime} onChange={e=>setForm({...form,endTime:e.target.value})} />
            </div>
          </div>
          <div style={{ display:'flex', gap:'8px' }}>
            <Btn onClick={createSession} disabled={creating} fullWidth>{creating?'Saving…':'Save'}</Btn>
            <Btn onClick={()=>setCreateOpen(false)} variant="white" fullWidth>Cancel</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
