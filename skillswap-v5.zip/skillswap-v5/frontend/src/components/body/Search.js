import React, { useState, useEffect } from 'react';
import { Search as SearchIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import PersonCard from './PersonCard';
import Loader from '../Loader/Loader';
import { C, EmptyState } from '../UIKit';

const CATS = ['All','Programming','Design','Marketing','Music','Language','Finance','Writing','Photography','Cooking','Fitness','Other'];

export default function SearchPage() {
  const { user_id } = useAuth();
  const [query,    setQuery]    = useState('');
  const [cat,      setCat]      = useState('All');
  const [allUsers, setAllUsers] = useState([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(()=>{
    if(!user_id) return;
    fetch(`/api/skills/all-users/${user_id}`).then(r=>r.json()).then(d=>{ setAllUsers(d.results||[]); setLoading(false); }).catch(()=>setLoading(false));
  }, [user_id]);

  const seen = new Set();
  const filtered = allUsers.filter(p=>{
    const q = query ? (p.username.toLowerCase().includes(query.toLowerCase()) || p.skill_name.toLowerCase().includes(query.toLowerCase())) : true;
    const c = cat!=='All' ? p.category===cat : true;
    const key = `${p.user_id}_${p.skill_id}`;
    if(seen.has(key)) return false; seen.add(key); return q&&c;
  });

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'1100px', margin:'0 auto' }}>
        <div style={{ marginBottom:'20px' }}>
          <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text, marginBottom:'4px' }}>Find People</h2>
          <p style={{ color:C.textMid, fontSize:'13px' }}>Discover skill exchange partners near you</p>
        </div>

        {/* Search bar */}
        <div style={{ position:'relative', marginBottom:'20px' }}>
          <SearchIcon size={16} style={{ position:'absolute', left:'14px', top:'50%', transform:'translateY(-50%)', color:C.textLight }} />
          <input type="text" placeholder="Search for skills or people…" value={query} onChange={e=>setQuery(e.target.value)}
            style={{ width:'100%', background:C.white, border:`1.5px solid ${C.border}`, borderRadius:'14px',
              padding:'14px 14px 14px 42px', fontSize:'15px', outline:'none', boxSizing:'border-box', fontFamily:'inherit' }}
            onFocus={e=>e.target.style.borderColor=C.blue}
            onBlur={e=>e.target.style.borderColor=C.border} />
        </div>

        {/* Category pills */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:'8px', marginBottom:'24px' }}>
          {CATS.map(c=>(
            <button key={c} onClick={()=>setCat(c)} className={`skill-pill${c===cat?' active':''}`}>{c}</button>
          ))}
        </div>

        <p style={{ color:C.textLight, fontSize:'13px', marginBottom:'20px' }}>
          {loading?'Searching…':`${filtered.length} result${filtered.length!==1?'s':''}`}
        </p>

        {loading ? <Loader fullPage /> : filtered.length===0
          ? <EmptyState icon="🔎" title="No results" subtitle="Try a different name, skill, or category." />
          : <div className="cards-grid">{filtered.map((p,i)=>(
              <PersonCard key={i} name={p.username} rating={p.rating} skills={p.skill_name}
                skill_id={p.skill_id} receiver_id={p.user_id} category={p.category} index={i} />
            ))}</div>}
      </div>
    </div>
  );
}
