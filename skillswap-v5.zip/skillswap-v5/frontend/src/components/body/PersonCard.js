import React, { useState } from 'react';
import { Star, BookOpen, ArrowLeftRight, Send, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { C, Btn, Badge, Modal, Input, Select, Avatar } from '../UIKit';

const CATS = ['Programming','Design','Marketing','Music','Language','Finance','Writing','Photography','Cooking','Fitness','Other'];

export default function PersonCard({ name, rating, skills, skill_id, receiver_id, category, index=0 }) {
  const { token } = useAuth();
  const [mode, setMode]       = useState(null);
  const [msg,  setMsg]        = useState('');
  const [learnSkill, setLearnSkill] = useState('');
  const [learnCat,   setLearnCat]   = useState('Programming');
  const [sent, setSent]       = useState(null);
  const [loading, setLoading] = useState(false);
  const stars = Math.round(rating || 0);
  const avatarBg = [`hsl(${(index*67)%360},55%,50%)`];

  async function sendRequest(type) {
    if (!msg.trim()) { alert('Please write a message'); return; }
    if (type==='learn' && !learnSkill.trim()) { alert('Enter the skill to learn'); return; }
    setLoading(true);
    try {
      const res  = await fetch('/api/requests', { method:'POST',
        headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
        body:JSON.stringify({ receiver_id, skill_id, message:msg, type:type==='learn'?'learnTogether':'swap', skillName:learnSkill }) });
      const data = await res.json();
      if (data.error) alert(data.error);
      else { setSent(type); setMode(null); setMsg(''); }
    } catch { alert('Failed to send request'); }
    finally { setLoading(false); }
  }

  return (
    <>
      <div style={{ background:C.white, borderRadius:'16px', border:`1px solid ${C.border}`,
        boxShadow:'0 2px 8px rgba(59,91,219,0.06)', width:'200px', padding:'20px',
        display:'flex', flexDirection:'column', gap:'12px', transition:'all 0.2s' }}
        onMouseEnter={e=>{ e.currentTarget.style.boxShadow='0 8px 24px rgba(59,91,219,0.12)'; e.currentTarget.style.transform='translateY(-3px)'; }}
        onMouseLeave={e=>{ e.currentTarget.style.boxShadow='0 2px 8px rgba(59,91,219,0.06)'; e.currentTarget.style.transform='translateY(0)'; }}>

        {/* Avatar */}
        <div style={{ display:'flex', justifyContent:'center' }}>
          <Avatar name={name} size={56} bg={avatarBg[0]} />
        </div>

        {/* Info */}
        <div style={{ textAlign:'center' }}>
          <p style={{ fontWeight:'700', fontSize:'15px', color:C.text, marginBottom:'5px' }}>{name}</p>
          <Badge label={category||'Other'} />
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:'5px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:'12px' }}>
            <span style={{ color:C.textMid }}>Skill</span>
            <span style={{ color:C.text, fontWeight:'600', maxWidth:'110px',
              overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{skills}</span>
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:'12px' }}>
            <span style={{ color:C.textMid }}>Rating</span>
            <div style={{ display:'flex', gap:'1px' }}>
              {[1,2,3,4,5].map(i=>(
                <Star key={i} size={11} fill={i<=stars?C.warn:'none'} color={i<=stars?C.warn:C.border} />
              ))}
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div style={{ display:'flex', flexDirection:'column', gap:'6px', paddingTop:'8px', borderTop:`1px solid ${C.border}` }}>
          {sent==='swap' ? (
            <p style={{ textAlign:'center', color:C.success, fontWeight:'600', fontSize:'12px' }}>✓ Request Sent</p>
          ) : sent==='learn' ? (
            <p style={{ textAlign:'center', color:'#7C3AED', fontWeight:'600', fontSize:'12px' }}>✓ Learn Together Sent</p>
          ) : (
            <>
              <Btn onClick={()=>setMode('swap')} size="sm" fullWidth>
                <ArrowLeftRight size={12}/> Send Request
              </Btn>
              <Btn onClick={()=>setMode('learn')} variant="outline" size="sm" fullWidth>
                <BookOpen size={12}/> Learn Together
              </Btn>
            </>
          )}
        </div>
      </div>

      {/* Swap Modal */}
      <Modal open={mode==='swap'} onClose={()=>setMode(null)} title="🔄 Skill Swap Request">
        <p style={{ color:C.textMid, fontSize:'13px', marginBottom:'16px' }}>
          Send a swap request to <strong style={{ color:C.text }}>{name}</strong> for <strong style={{ color:C.blue }}>{skills}</strong>
        </p>
        <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
          <Input placeholder="Hi! I'd love to swap skills with you…" value={msg}
            onChange={e=>setMsg(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendRequest('swap')} />
          <div style={{ display:'flex', gap:'8px' }}>
            <Btn onClick={()=>sendRequest('swap')} disabled={loading||!msg.trim()} fullWidth>
              <Send size={14}/>{loading?'Sending…':'Send Request'}
            </Btn>
            <Btn onClick={()=>{ setMode(null); setMsg(''); }} variant="white" fullWidth>Cancel</Btn>
          </div>
        </div>
      </Modal>

      {/* Learn Together Modal */}
      <Modal open={mode==='learn'} onClose={()=>setMode(null)} title="📚 Learn Together">
        <p style={{ color:C.textMid, fontSize:'13px', marginBottom:'16px' }}>
          Ask <strong style={{ color:C.text }}>{name}</strong> to learn a new skill together!
        </p>
        <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
          <Input placeholder="Skill to learn e.g. Machine Learning, Guitar…" value={learnSkill}
            onChange={e=>setLearnSkill(e.target.value)} />
          <Select value={learnCat} onChange={e=>setLearnCat(e.target.value)}>
            {CATS.map(c=><option key={c} value={c}>{c}</option>)}
          </Select>
          <Input placeholder="Your message…" value={msg}
            onChange={e=>setMsg(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendRequest('learn')} />
          <div style={{ display:'flex', gap:'8px' }}>
            <Btn onClick={()=>sendRequest('learn')} disabled={loading||!msg.trim()||!learnSkill.trim()} fullWidth
              style={{ background:'#7C3AED' }}>
              <BookOpen size={14}/>{loading?'Sending…':'Send Request'}
            </Btn>
            <Btn onClick={()=>{ setMode(null); setMsg(''); setLearnSkill(''); }} variant="white" fullWidth>Cancel</Btn>
          </div>
        </div>
      </Modal>
    </>
  );
}
