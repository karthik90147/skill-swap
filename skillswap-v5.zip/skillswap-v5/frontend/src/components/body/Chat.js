import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from "../context/AuthContext';
import { useSocket } from "../context/SocketContext';
import { Send } from "lucide-react";
import { useLocation } from 'react-router-dom';
import { EmptyState, Avatar, OnlineDot } from "../UIKit";
import Loader from "../Loader/Loader";

export default function Chat() {
  const { user_id, token }    = useAuth();
  const { socket, onlineUsers } = useSocket();
  const [conversations, setConversations] = useState([]);
  const [activeChat, setActiveChat]       = useState(null);
  const [messages,   setMessages]         = useState([]);
  const [text, setText]                   = useState('');
  const [loading, setLoading]             = useState(true);
  const [msgLoading, setMsgLoading]       = useState(false);
  const [friendTyping, setFriendTyping]   = useState(false);
  const location = useLocation();
  const bottomRef  = useRef(null);
  const typingRef  = useRef(null);
  const isTyping   = useRef(false);

  // Auto-open chat if navigated from FriendCard
  useEffect(() => {
    if (location.state?.partner_id) {
      setActiveChat({ partner_id: location.state.partner_id, partner_name: location.state.partner_name });
    }
  }, [location.state]);

  // Load conversation list
  useEffect(() => {
    if (!token) return;
    fetch('/api/messages', { headers:{ Authorization:`Bearer ${token}` } })
      .then(r=>r.json())
      .then(d=>{ setConversations(d.conversations||[]); setLoading(false); })
      .catch(()=>setLoading(false));
  }, [token]);

  // Load messages for active chat
  useEffect(() => {
    if (!activeChat || !token) return;
    setMsgLoading(true);
    setMessages([]);
    fetch(`/api/messages/${activeChat.partner_id}`, { headers:{ Authorization:`Bearer ${token}` } })
      .then(r=>r.json())
      .then(d=>{ setMessages(d.messages||[]); setMsgLoading(false); })
      .catch(()=>setMsgLoading(false));
  }, [activeChat, token]);

  // Socket listeners
  useEffect(() => {
    if (!socket) return;

    // Listen for messages sent by ME (confirmed by server)
    socket.on('message_sent', (msg) => {
      setMessages(prev => prev.find(m=>m._id===msg._id) ? prev : [...prev, msg]);
    });

    // Listen for messages from others
    socket.on('receive_message', (msg) => {
      // Only show if we're in this conversation
      const myId = user_id?.toString();
      const inConv = activeChat &&
        (msg.sender_id?.toString() === activeChat.partner_id?.toString() ||
         msg.receiver_id?.toString() === activeChat.partner_id?.toString());

      if (inConv) {
        setMessages(prev => prev.find(m=>m._id===msg._id) ? prev : [...prev, msg]);
      }

      // Update conversation list
      setConversations(prev => {
        const partnerId = msg.sender_id?.toString() === myId ? msg.receiver_id?.toString() : msg.sender_id?.toString();
        const exists = prev.find(c => c.partner_id?.toString() === partnerId);
        if (exists) {
          return prev.map(c => c.partner_id?.toString() === partnerId
            ? { ...c, last_message: msg.text, last_time: msg.createdAt }
            : c);
        }
        return [{ partner_id: partnerId, partner_name: msg.sender_name, last_message: msg.text, last_time: msg.createdAt, unread: 0 }, ...prev];
      });
    });

    socket.on('user_typing', ({ sender_id, isTyping }) => {
      if (activeChat && sender_id?.toString() === activeChat.partner_id?.toString()) {
        setFriendTyping(isTyping);
      }
    });

    return () => {
      socket.off('message_sent');
      socket.off('receive_message');
      socket.off('user_typing');
    };
  }, [socket, activeChat, user_id]);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior:'smooth' });
  }, [messages, friendTyping]);

  function sendMessage() {
    if (!text.trim() || !activeChat) return;
    if (!socket) { alert('Not connected to chat server. Please wait…'); return; }
    socket.emit('send_message', { receiver_id: activeChat.partner_id, text: text.trim() });
    setText('');
    stopTyping();
  }

  function stopTyping() {
    if (socket && activeChat && isTyping.current) {
      socket.emit('typing', { receiver_id: activeChat.partner_id, isTyping: false });
      isTyping.current = false;
    }
  }

  function handleTyping(val) {
    setText(val);
    if (!socket || !activeChat) return;
    if (!isTyping.current) {
      isTyping.current = true;
      socket.emit('typing', { receiver_id: activeChat.partner_id, isTyping: true });
    }
    clearTimeout(typingRef.current);
    typingRef.current = setTimeout(stopTyping, 1500);
  }

  const isOnline = id => onlineUsers.includes(id?.toString());
  const fmtTime  = d  => new Date(d).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });

  return (
    <div style={{ display:'flex', height:'calc(100vh - 60px)', background:'#0f172a' }}>

      {/* Sidebar */}
      <div style={{ width:'300px', borderRight:'1px solid #334155', display:'flex', flexDirection:'column', flexShrink:0 }}>
        <div style={{ padding:'20px 16px', borderBottom:'1px solid #334155' }}>
          <h2 style={{ fontWeight:'800', fontSize:'18px', color:'#f8fafc' }}>Messages</h2>
          <p style={{ color:'#94a3b8', fontSize:'12px', marginTop:'2px' }}>
            {socket ? '🟢 Connected' : '🔴 Connecting…'}
          </p>
        </div>
        <div style={{ flex:1, overflowY:'auto' }}>
          {loading ? <div style={{ padding:'24px' }}><Loader /></div> : conversations.length===0 ? (
            <div style={{ padding:'32px 16px', textAlign:'center' }}>
              <p style={{ fontSize:'36px', marginBottom:'8px' }}>💬</p>
              <p style={{ color:'#94a3b8', fontSize:'13px' }}>No conversations yet.</p>
              <p style={{ color:'#94a3b8', fontSize:'13px', marginTop:'4px' }}>Chat with your friends!</p>
            </div>
          ) : conversations.map((c,i) => (
            <div key={i} onClick={()=>{ setActiveChat(c); setFriendTyping(false); }}
              style={{ padding:'14px 16px', cursor:'pointer', borderBottom:'1px solid #1e293b',
                background: activeChat?.partner_id===c.partner_id ? '#263348' : 'transparent',
                display:'flex', gap:'12px', alignItems:'center', transition:'background 0.2s' }}>
              <div style={{ position:'relative', flexShrink:0 }}>
                <Avatar name={c.partner_name} size={42} />
                <div style={{ position:'absolute', bottom:1, right:1 }}>
                  <OnlineDot online={isOnline(c.partner_id)} size={11} />
                </div>
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <p style={{ fontWeight:'700', color:'#f8fafc', fontSize:'14px' }}>{c.partner_name}</p>
                  {c.unread>0 && <span style={{ background:'#6366f1', color:'white', borderRadius:'9999px',
                    fontSize:'10px', fontWeight:'bold', padding:'1px 6px' }}>{c.unread}</span>}
                </div>
                <p style={{ color:'#94a3b8', fontSize:'12px', whiteSpace:'nowrap',
                  overflow:'hidden', textOverflow:'ellipsis', marginTop:'2px' }}>{c.last_message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat window */}
      <div style={{ flex:1, display:'flex', flexDirection:'column' }}>
        {!activeChat ? (
          <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <EmptyState icon="💬" title="Select a conversation" subtitle="Pick a friend from the left to start chatting in real time" />
          </div>
        ) : (
          <>
            {/* Header */}
            <div style={{ padding:'14px 20px', borderBottom:'1px solid #334155', background:'#1e293b',
              display:'flex', alignItems:'center', gap:'12px' }}>
              <div style={{ position:'relative' }}>
                <Avatar name={activeChat.partner_name} size={40} />
                <div style={{ position:'absolute', bottom:1, right:1 }}>
                  <OnlineDot online={isOnline(activeChat.partner_id)} size={11} />
                </div>
              </div>
              <div>
                <p style={{ fontWeight:'700', color:'#f8fafc', fontSize:'15px' }}>{activeChat.partner_name}</p>
                <p style={{ fontSize:'12px', color: isOnline(activeChat.partner_id)?'#22c55e':'#94a3b8' }}>
                  {isOnline(activeChat.partner_id) ? '● Online' : '○ Offline'}
                </p>
              </div>
            </div>

            {/* Messages */}
            <div style={{ flex:1, overflowY:'auto', padding:'20px', display:'flex', flexDirection:'column', gap:'10px' }}>
              {msgLoading ? <Loader /> : messages.length===0 ? (
                <div style={{ textAlign:'center', color:'#94a3b8', marginTop:'40px', fontSize:'14px' }}>
                  No messages yet. Say hello! 👋
                </div>
              ) : messages.map((msg,i) => {
                const mine = msg.sender_id?.toString() === user_id?.toString();
                return (
                  <div key={i} style={{ display:'flex', justifyContent:mine?'flex-end':'flex-start' }}>
                    <div style={{
                      maxWidth:'65%', padding:'10px 14px',
                      borderRadius: mine?'16px 16px 4px 16px':'16px 16px 16px 4px',
                      background: mine?'#6366f1':'#1e293b',
                      border: mine?'none':'1px solid #334155',
                    }}>
                      <p style={{ color:'#f8fafc', fontSize:'14px', lineHeight:'1.5', wordBreak:'break-word' }}>{msg.text}</p>
                      <p style={{ color:mine?'#c7d2fe':'#475569', fontSize:'10px', marginTop:'4px', textAlign:'right' }}>
                        {fmtTime(msg.createdAt)}
                      </p>
                    </div>
                  </div>
                );
              })}
              {friendTyping && (
                <div style={{ display:'flex', alignItems:'center', gap:'6px' }}>
                  <div style={{ background:'#1e293b', border:'1px solid #334155', borderRadius:'12px', padding:'8px 14px' }}>
                    <p style={{ color:'#94a3b8', fontSize:'13px' }}>{activeChat.partner_name} is typing…</p>
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div style={{ padding:'16px 20px', borderTop:'1px solid #334155', background:'#1e293b',
              display:'flex', gap:'10px', alignItems:'center' }}>
              <input value={text}
                onChange={e=>handleTyping(e.target.value)}
                onKeyDown={e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); sendMessage(); } }}
                placeholder={`Message ${activeChat.partner_name}…`}
                style={{ flex:1, background:'#334155', color:'#f8fafc', border:'1px solid #334155',
                  borderRadius:'9999px', padding:'10px 16px', fontSize:'14px', outline:'none' }}
                onFocus={e=>e.target.style.borderColor='#6366f1'}
                onBlur={e=>e.target.style.borderColor='#334155'}
              />
              <button onClick={sendMessage} disabled={!text.trim()}
                style={{ width:'42px', height:'42px', borderRadius:'50%', border:'none',
                  background:text.trim()?'#6366f1':'#334155', color:'white',
                  cursor:text.trim()?'pointer':'not-allowed', transition:'background 0.2s',
                  display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                <Send size={16}/>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
// Note: Chat.js already handles this via useLocation state in FriendCard navigation
