import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { C, Card, Badge, Btn, Input, Select, Modal, EmptyState, Avatar } from '../UIKit';
import { Plus, Trash2, ArrowLeft, LogOut, ChevronRight } from 'lucide-react';

const CATS = ['Programming','Design','Marketing','Music','Language','Finance','Writing','Photography','Cooking','Fitness','Other'];

export default function Profile() {
  const { user_id, username, token, logout } = useAuth();
  const navigate = useNavigate();
  const [skills,   setSkills]   = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [newSkill, setNewSkill] = useState('');
  const [newCat,   setNewCat]   = useState('Other');
  const [addOpen,  setAddOpen]  = useState(false);
  const [adding,   setAdding]   = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  useEffect(()=>{
    if(!user_id) return;
    fetch(`/api/skills/user/${user_id}`,{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>{ setSkills(d.results||[]); setLoading(false); });
  }, [user_id, token]);

  async function addSkill() {
    if(!newSkill.trim()) return;
    const name = newSkill.trim().split(' ').map(w=>w.charAt(0).toUpperCase()+w.slice(1).toLowerCase()).join(' ');
    setAdding(true);
    try {
      const res  = await fetch('/api/skills',{ method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`}, body:JSON.stringify({ name, category:newCat }) });
      const data = await res.json();
      if(data.error) alert(data.error);
      else { setSkills(p=>[...p,{ userskill_id:data.skill_id+Date.now(), skill_name:name, category:newCat, rating:0 }]); setNewSkill(''); setAddOpen(false); }
    } catch { alert('Failed'); } finally { setAdding(false); }
  }

  async function deleteSkill(id) {
    try {
      const res  = await fetch(`/api/skills/${id}`,{ method:'DELETE', headers:{ Authorization:`Bearer ${token}` }});
      const data = await res.json();
      if(!data.error) setSkills(p=>p.filter(s=>s.userskill_id!==id));
    } catch { alert('Failed'); } finally { setDeleteId(null); }
  }

  const grouped = skills.reduce((acc,s)=>{ const c=s.category||'Other'; if(!acc[c])acc[c]=[]; acc[c].push(s); return acc; },{});

  const menuItems = [
    { icon:'📋', label:'Personal Info' },
    { icon:'🔔', label:'Notifications', to:'/notifications' },
    { icon:'🔒', label:'Security' },
    { icon:'❓', label:'Help Center' },
    { icon:'💬', label:'FAQ\'s' },
  ];

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'600px', margin:'0 auto' }}>

        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', gap:'12px', marginBottom:'24px' }}>
          <button onClick={()=>navigate(-1)} style={{ background:C.white, border:`1px solid ${C.border}`,
            borderRadius:'10px', padding:'8px', cursor:'pointer', display:'flex' }}><ArrowLeft size={18} color={C.text}/></button>
          <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text }}>Your Profile</h2>
        </div>

        {/* Profile Card */}
        <Card style={{ padding:'24px', marginBottom:'16px', display:'flex', alignItems:'center', gap:'20px' }}>
          <Avatar name={username} size={64} />
          <div style={{ flex:1 }}>
            <p style={{ fontWeight:'800', fontSize:'18px', color:C.text, marginBottom:'2px' }}>{username}</p>
            <p style={{ color:C.textMid, fontSize:'13px' }}>Hyderabad, India</p>
            <p style={{ color:C.blue, fontSize:'13px', fontWeight:'600', marginTop:'4px' }}>{skills.length} skills · {skills.filter(s=>s.rating>0).length} rated</p>
          </div>
          <Btn variant="outline" size="sm">PRO ✨</Btn>
        </Card>

        {/* Skills section */}
        <Card style={{ padding:'20px', marginBottom:'16px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <p style={{ fontWeight:'700', color:C.text, fontSize:'15px' }}>Your Skills</p>
            <Btn onClick={()=>setAddOpen(true)} size="sm"><Plus size={13}/>Add</Btn>
          </div>
          {loading ? <p style={{ color:C.textLight, fontSize:'13px' }}>Loading…</p>
          : skills.length===0 ? <EmptyState icon="🧠" title="No skills yet" subtitle='Tap "Add" to list your skills.' />
          : Object.entries(grouped).map(([cat,catSkills])=>(
            <div key={cat} style={{ marginBottom:'14px' }}>
              <div style={{ display:'flex', alignItems:'center', gap:'6px', marginBottom:'8px' }}>
                <Badge label={cat} />
                <span style={{ color:C.textLight, fontSize:'11px' }}>{catSkills.length}</span>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
                {catSkills.map(s=>(
                  <div key={s.userskill_id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                    background:C.bg, borderRadius:'10px', padding:'10px 14px' }}>
                    <div>
                      <p style={{ fontWeight:'600', color:C.text, fontSize:'14px' }}>{s.skill_name}</p>
                      {s.rating>0 && <p style={{ color:C.warn, fontSize:'11px' }}>⭐ {s.rating}/5</p>}
                    </div>
                    <button onClick={()=>setDeleteId(s.userskill_id)} style={{ background:C.danger+'18',
                      border:'none', borderRadius:'8px', padding:'5px 7px', cursor:'pointer', color:C.danger, display:'flex' }}>
                      <Trash2 size={13}/>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </Card>

        {/* Menu items */}
        <Card style={{ marginBottom:'16px', overflow:'hidden' }}>
          {menuItems.map((item,i)=>(
            <div key={i} onClick={()=>item.to&&navigate(item.to)} style={{
              display:'flex', alignItems:'center', justifyContent:'space-between',
              padding:'16px 20px', borderBottom:i<menuItems.length-1?`1px solid ${C.border}`:'none',
              cursor:'pointer', transition:'background 0.15s' }}
              onMouseEnter={e=>e.currentTarget.style.background=C.bg}
              onMouseLeave={e=>e.currentTarget.style.background='white'}>
              <div style={{ display:'flex', alignItems:'center', gap:'12px' }}>
                <span style={{ fontSize:'18px' }}>{item.icon}</span>
                <span style={{ fontWeight:'500', color:C.text, fontSize:'14px' }}>{item.label}</span>
              </div>
              <ChevronRight size={16} color={C.textLight}/>
            </div>
          ))}
        </Card>

        {/* Logout */}
        <button onClick={()=>{ logout(); navigate('/auth'); }} style={{
          width:'100%', background:'none', border:`1.5px solid ${C.danger}`, borderRadius:'12px',
          padding:'13px', color:C.danger, fontWeight:'700', fontSize:'14px', cursor:'pointer',
          display:'flex', alignItems:'center', justifyContent:'center', gap:'8px', fontFamily:'inherit' }}>
          <LogOut size={16}/> Logout
        </button>
      </div>

      <Modal open={addOpen} onClose={()=>setAddOpen(false)} title="➕ Add Skill">
        <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
          <Input placeholder="e.g. React, Guitar, Spanish…" value={newSkill}
            onChange={e=>setNewSkill(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addSkill()} />
          <Select value={newCat} onChange={e=>setNewCat(e.target.value)}>
            {CATS.map(c=><option key={c} value={c}>{c}</option>)}
          </Select>
          <div style={{ display:'flex', gap:'8px' }}>
            <Btn onClick={addSkill} disabled={adding||!newSkill.trim()} fullWidth>{adding?'Adding…':'Add Skill'}</Btn>
            <Btn onClick={()=>setAddOpen(false)} variant="white" fullWidth>Cancel</Btn>
          </div>
        </div>
      </Modal>

      <Modal open={!!deleteId} onClose={()=>setDeleteId(null)} title="Remove Skill?">
        <p style={{ color:C.textMid, marginBottom:'20px' }}>Are you sure you want to remove this skill?</p>
        <div style={{ display:'flex', gap:'8px' }}>
          <Btn onClick={()=>deleteSkill(deleteId)} variant="danger" fullWidth>Yes, Remove</Btn>
          <Btn onClick={()=>setDeleteId(null)} variant="white" fullWidth>Cancel</Btn>
        </div>
      </Modal>
    </div>
  );
}
