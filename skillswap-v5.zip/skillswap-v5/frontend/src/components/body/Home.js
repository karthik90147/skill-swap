import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useUser } from '../context/UserContext';
import useFetch from '../hook/useFetch';
import PersonCard from './PersonCard';
import Loader from '../Loader/Loader';
import { C, SectionHeader, Avatar, EmptyState } from '../UIKit';

function StatCard({ icon, label, value, color, to }) {
  const navigate = useNavigate();
  return (
    <div onClick={()=>to&&navigate(to)} style={{
      background: C.white, borderRadius:'16px', padding:'18px 20px',
      display:'flex', alignItems:'center', gap:'14px', flex:1, minWidth:'140px',
      border:`1px solid ${C.border}`, boxShadow:'0 2px 8px rgba(59,91,219,0.06)',
      cursor:to?'pointer':'default', transition:'all 0.2s',
    }}
      onMouseEnter={e=>{ if(to){ e.currentTarget.style.boxShadow='0 6px 20px rgba(59,91,219,0.12)'; e.currentTarget.style.transform='translateY(-2px)'; }}}
      onMouseLeave={e=>{ if(to){ e.currentTarget.style.boxShadow='0 2px 8px rgba(59,91,219,0.06)'; e.currentTarget.style.transform='translateY(0)'; }}}
    >
      <div style={{ width:'44px', height:'44px', borderRadius:'12px',
        background:(color||C.blue)+'18', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'20px' }}>
        {icon}
      </div>
      <div>
        <p style={{ color:C.textLight, fontSize:'12px', fontWeight:'500' }}>{label}</p>
        <p style={{ color:C.text, fontWeight:'800', fontSize:'20px' }}>{value??'0'}</p>
      </div>
    </div>
  );
}

const TRENDING = ['Cooking','Music','Dance','Photography','Coding','Design','Language','Fitness'];

export default function Home() {
  const { user_id, username, token } = useAuth();
  const { setPersons, filterPersons } = useUser();
  const navigate = useNavigate();
  const [mySkills, setMySkills]       = useState([]);
  const [recommended, setRecommended] = useState([]);
  const [popularUsers, setPopularUsers] = useState([]);

  const { data, loading, error } = useFetch({ url: user_id ? `/api/skills/all-users/${user_id}` : null });
  const { data: stats }          = useFetch({ url: user_id ? `/api/requests/stats/${user_id}` : null });

  useEffect(() => { if(data?.results) setPersons(data.results); }, [data, setPersons]);
  useEffect(() => { if(error==='Unauthorized'||!user_id) navigate('/auth'); }, [error, user_id, navigate]);

  useEffect(() => {
    if (!user_id) return;
    fetch(`/api/skills/user/${user_id}`,{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>setMySkills(d.results||[]));
  }, [user_id, token]);

  useEffect(() => {
    if (!data?.results) return;
    const myCats = new Set(mySkills.map(s=>s.category));
    const recs = data.results.filter(p=>myCats.has(p.category)).slice(0,8);
    setRecommended(recs);
    // Popular = users with highest rating
    const sorted = [...data.results].sort((a,b)=>b.rating-a.rating);
    const seen = new Set();
    const pop = [];
    for (const u of sorted) {
      if (!seen.has(u.user_id?.toString())) { seen.add(u.user_id?.toString()); pop.push(u); }
      if (pop.length >= 6) break;
    }
    setPopularUsers(pop);
  }, [data, mySkills]);

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh' }}>

      {/* Hero Banner */}
      <div style={{ background:`linear-gradient(135deg,${C.blue} 0%,#5B7FE8 100%)`,
        padding:'28px 24px', margin:'0 0 24px' }}>
        <div style={{ maxWidth:'1100px', margin:'0 auto', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div style={{ color:'white' }}>
            <p style={{ fontSize:'13px', opacity:0.8, marginBottom:'6px', fontWeight:'500' }}>Welcome back, {username}! 👋</p>
            <h1 style={{ fontWeight:'800', fontSize:'22px', marginBottom:'12px', lineHeight:'1.3' }}>
              Find Your Perfect Skill<br/>Exchange Partner
            </h1>
            <button onClick={()=>navigate('/search')} style={{
              background:'white', color:C.blue, border:'none', borderRadius:'10px',
              padding:'10px 20px', fontWeight:'700', fontSize:'14px', cursor:'pointer' }}>
              View Matches
            </button>
          </div>
          {/* Floating avatars decoration */}
          <div style={{ display:'flex', gap:'8px', flexWrap:'wrap', maxWidth:'160px', opacity:0.9 }}>
            {['A','K','R','M','S','P'].map((l,i)=>(
              <div key={i} style={{ width:'36px', height:'36px', borderRadius:'50%', border:'2px solid white',
                background:`hsl(${i*60},60%,55%)`, display:'flex', alignItems:'center', justifyContent:'center',
                fontWeight:'700', fontSize:'13px', color:'white' }}>{l}</div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:'1100px', margin:'0 auto', padding:'0 20px' }}>

        {/* Stats */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:'12px', marginBottom:'28px' }}>
          <StatCard icon="🧠" label="Your Skills"   value={stats?.skillCount}    color={C.blue}    to="/profile" />
          <StatCard icon="📥" label="Requests In"   value={stats?.totalReceived} color="#7C3AED"   to="/req" />
          <StatCard icon="🤝" label="Friends"       value={stats?.accepted}      color={C.success} to="/friendlist" />
          <StatCard icon="⏳" label="Pending"       value={stats?.pending}       color={C.warn}    to="/req" />
          <StatCard icon="💬" label="Messages"      value={null}                 color="#0891B2"   to="/chat" />
        </div>

        {/* Trending Skills */}
        <div style={{ marginBottom:'28px' }}>
          <SectionHeader title="Trending skills" action="View more ›" onAction={()=>navigate('/search')} />
          <div style={{ display:'flex', gap:'10px', overflowX:'auto', paddingBottom:'8px' }}>
            {TRENDING.map((skill,i)=>(
              <div key={skill} style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:'40px',
                padding:'10px 18px', display:'flex', alignItems:'center', gap:'10px',
                whiteSpace:'nowrap', cursor:'pointer', transition:'all 0.2s', boxShadow:'0 1px 4px rgba(59,91,219,0.06)' }}
                onMouseEnter={e=>{ e.currentTarget.style.borderColor=C.blue; e.currentTarget.style.color=C.blue; }}
                onMouseLeave={e=>{ e.currentTarget.style.borderColor=C.border; e.currentTarget.style.color=C.text; }}>
                <div style={{ width:'28px', height:'28px', borderRadius:'50%',
                  background:`hsl(${i*45},55%,55%)`, display:'flex', alignItems:'center',
                  justifyContent:'center', fontSize:'14px' }}>
                  {['🍳','🎵','💃','📷','💻','🎨','🌍','💪'][i]}
                </div>
                <span style={{ fontWeight:'600', fontSize:'13px' }}>{skill}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Nearby People (Recommended) */}
        {(loading || recommended.length > 0) && (
          <div style={{ marginBottom:'28px' }}>
            <SectionHeader title="Nearby people" action="View more ›" onAction={()=>navigate('/search')} />
            {loading ? <Loader /> : (
              <div style={{ display:'flex', gap:'16px', overflowX:'auto', paddingBottom:'8px' }}>
                {recommended.slice(0,6).map((p,i)=>(
                  <div key={i} style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:'16px',
                    padding:'16px', minWidth:'160px', display:'flex', flexDirection:'column',
                    alignItems:'center', gap:'8px', boxShadow:'0 2px 8px rgba(59,91,219,0.06)' }}>
                    <Avatar name={p.username} size={52} bg={`hsl(${i*60},55%,50%)`} />
                    <p style={{ fontWeight:'700', fontSize:'13px', color:C.text, textAlign:'center' }}>{p.username}</p>
                    <p style={{ fontSize:'11px', color:C.textMid, textAlign:'center' }}>{p.skill_name}</p>
                    <button onClick={()=>navigate('/search')} style={{ background:C.blue, color:'white',
                      border:'none', borderRadius:'8px', padding:'6px 14px', fontSize:'12px',
                      fontWeight:'600', cursor:'pointer', width:'100%' }}>View profile</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Popular Users */}
        {popularUsers.length > 0 && (
          <div style={{ marginBottom:'28px' }}>
            <SectionHeader title="Popular users" action="View more ›" onAction={()=>navigate('/search')} />
            <div style={{ display:'flex', gap:'16px', overflowX:'auto', paddingBottom:'8px' }}>
              {popularUsers.map((u,i)=>(
                <div key={i} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:'6px', cursor:'pointer' }}
                  onClick={()=>navigate('/search')}>
                  <Avatar name={u.username} size={52} bg={`hsl(${i*50},55%,50%)`} />
                  <p style={{ fontSize:'12px', fontWeight:'600', color:C.text, textAlign:'center', maxWidth:'60px',
                    overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{u.username}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* All People & Skills */}
        <div style={{ marginBottom:'28px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <h3 style={{ fontWeight:'700', fontSize:'16px', color:C.text }}>People & Skills</h3>
            <span style={{ color:C.textLight, fontSize:'13px' }}>{filterPersons.length} results</span>
          </div>
          {loading ? <Loader fullPage /> : filterPersons.length === 0 ? (
            <EmptyState icon="🔍" title="No users found" subtitle="Try a different filter or add skills to your profile." />
          ) : (
            <div className="cards-grid">
              {filterPersons.map((p,i)=>(
                <PersonCard key={i} name={p.username} rating={p.rating}
                  skills={p.skill_name} skill_id={p.skill_id}
                  receiver_id={p.user_id} category={p.category} index={i} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
