import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { C, Card, Btn, Badge, Avatar, EmptyState, Modal } from '../UIKit';
import Loader from '../Loader/Loader';
import { MessageCircle, Star } from 'lucide-react';
import FeedbackReport from './FeedbackReport';

function FriendCard({ name, skill, skill_id, requester_id, request_id, category, token, user_id }) {
  const navigate = useNavigate();
  const [rating, setRating]       = useState(0);
  const [hover, setHover]         = useState(0);
  const [showRating, setShowRating] = useState(false);
  const [rated, setRated]         = useState(false);
  const [fbOpen, setFbOpen]       = useState(false);

  async function submitRating() {
    if (!rating) return;
    try {
      await fetch('/api/requests/respond',{ method:'POST',
        headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
        body:JSON.stringify({ request_id, status:'accepted', requester_id, skill_id, rating }) });
      setRated(true); setShowRating(false);
    } catch { alert('Failed'); }
  }

  return (
    <>
      <Card style={{ padding:'20px', display:'flex', gap:'14px', alignItems:'center' }}>
        <Avatar name={name} size={50} bg={`hsl(${name?.charCodeAt(0)*37%360},50%,50%)`} />
        <div style={{ flex:1 }}>
          <p style={{ fontWeight:'700', color:C.text, fontSize:'15px', marginBottom:'3px' }}>{name}</p>
          <Badge label={category||'Other'} />
          <p style={{ color:C.textMid, fontSize:'12px', marginTop:'4px' }}>{skill}</p>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
          <Btn onClick={()=>navigate('/chat',{ state:{ partner_id:requester_id, partner_name:name }})} size="sm" variant="ghost">
            <MessageCircle size={13}/> Chat
          </Btn>
          {rated ? (
            <p style={{ fontSize:'12px', color:C.success, fontWeight:'600', textAlign:'center' }}>⭐ Rated</p>
          ) : showRating ? (
            <div>
              <div style={{ display:'flex', gap:'2px', justifyContent:'center', marginBottom:'6px' }}>
                {[1,2,3,4,5].map(i=>(
                  <span key={i} className="star" style={{ fontSize:'18px', color:i<=(hover||rating)?C.warn:C.border }}
                    onMouseEnter={()=>setHover(i)} onMouseLeave={()=>setHover(0)} onClick={()=>setRating(i)}>★</span>
                ))}
              </div>
              <Btn onClick={submitRating} size="sm" variant="success" fullWidth disabled={!rating}>Rate</Btn>
            </div>
          ) : (
            <Btn onClick={()=>setShowRating(true)} size="sm" variant="white">
              <Star size={13}/> Rate
            </Btn>
          )}
          <button onClick={()=>setFbOpen(true)} style={{ background:'none', border:'none',
            color:C.danger, fontSize:'11px', cursor:'pointer', fontWeight:'600' }}>Report</button>
        </div>
      </Card>
      <Modal open={fbOpen} onClose={()=>setFbOpen(false)} title={`Feedback for ${name}`}>
        <FeedbackReport targetId={requester_id} targetName={name} onClose={()=>setFbOpen(false)} />
      </Modal>
    </>
  );
}

export default function Friends() {
  const { user_id, token } = useAuth();
  const [friends, setFriends] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    if(!user_id) return;
    fetch(`/api/requests/friends/${user_id}`,{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>{ setFriends(d.results||[]); setLoading(false); }).catch(()=>setLoading(false));
  }, [user_id, token]);

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'700px', margin:'0 auto' }}>
        <div style={{ marginBottom:'24px' }}>
          <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text }}>Friend List</h2>
          <p style={{ color:C.textMid, fontSize:'13px', marginTop:'2px' }}>{friends.length} connections</p>
        </div>
        {loading ? <Loader fullPage /> : friends.length===0
          ? <EmptyState icon="🤝" title="No friends yet" subtitle="Accept skill swap requests to build your network." />
          : <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
              {friends.map((f,i)=><FriendCard key={i} name={f.requester_name} skill={f.requester_skills}
                skill_id={f.skill_id} requester_id={f.requester_id} request_id={f.request_id}
                category={f.category} token={token} user_id={user_id} />)}
            </div>}
      </div>
    </div>
  );
}
