import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { C, Card, Badge, Btn, Avatar, EmptyState } from '../UIKit';
import Loader from '../Loader/Loader';

function ReqCard({ name, skill, message, skill_id, requester_id, request_id, category, type, token }) {
  const [status, setStatus]   = useState('pending');
  const [loading, setLoading] = useState(false);

  async function respond(accept) {
    setLoading(true);
    try {
      const res = await fetch('/api/requests/respond',{ method:'POST',
        headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
        body:JSON.stringify({ request_id, status:accept?'accepted':'rejected', requester_id, skill_id }) });
      const data = await res.json();
      if (!data.error) setStatus(accept?'accepted':'rejected');
    } catch { alert('Failed to respond'); }
    finally { setLoading(false); }
  }

  if (status==='rejected') return null;
  const isLearn = type==='learnTogether';

  return (
    <Card style={{ padding:'20px', display:'flex', gap:'16px', alignItems:'flex-start' }}>
      <Avatar name={name} size={48} bg={isLearn?'#7C3AED':C.blue} />
      <div style={{ flex:1 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'8px', marginBottom:'8px' }}>
          <p style={{ fontWeight:'700', color:C.text, fontSize:'15px' }}>{name}</p>
          <div style={{ display:'flex', gap:'6px' }}>
            <Badge label={category||'Other'} />
            {isLearn && <span style={{ background:'#7C3AED18', color:'#7C3AED', borderRadius:'99px', padding:'2px 8px', fontSize:'11px', fontWeight:'700' }}>📚 Learn Together</span>}
          </div>
        </div>
        <p style={{ fontSize:'13px', color:C.textMid, marginBottom:'4px' }}><strong style={{ color:C.text }}>Skill:</strong> {skill}</p>
        <p style={{ fontSize:'13px', color:C.textMid, fontStyle:'italic', marginBottom:'12px' }}>"{message}"</p>
        {status==='accepted'
          ? <p style={{ color:C.success, fontWeight:'700', fontSize:'13px' }}>✓ Accepted</p>
          : <div style={{ display:'flex', gap:'8px' }}>
              <Btn onClick={()=>respond(true)}  variant="success" size="sm" disabled={loading}>✓ Accept</Btn>
              <Btn onClick={()=>respond(false)} variant="danger"  size="sm" disabled={loading}>✕ Reject</Btn>
            </div>}
      </div>
    </Card>
  );
}

export default function Requests() {
  const { user_id, token } = useAuth();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading]   = useState(true);

  useEffect(()=>{
    if(!user_id) return;
    fetch(`/api/requests/received/${user_id}`,{ headers:{ Authorization:`Bearer ${token}` }})
      .then(r=>r.json()).then(d=>{ setRequests(d.results||[]); setLoading(false); }).catch(()=>setLoading(false));
  }, [user_id, token]);

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'700px', margin:'0 auto' }}>
        <div style={{ marginBottom:'24px' }}>
          <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text }}>Requests</h2>
          <p style={{ color:C.textMid, fontSize:'13px', marginTop:'2px' }}>{requests.length} pending</p>
        </div>
        {loading ? <Loader fullPage /> : requests.length===0
          ? <EmptyState icon="📭" title="No pending requests" subtitle="When someone sends you a skill request it'll appear here." />
          : <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
              {requests.map((r,i)=><ReqCard key={i} {...r} requester_name={r.requester_name}
                name={r.requester_name} skill={r.requester_skills} token={token} />)}
            </div>}
      </div>
    </div>
  );
}
