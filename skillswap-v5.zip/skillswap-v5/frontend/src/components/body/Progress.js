import React from 'react';
import { useAuth } from '../context/AuthContext';
import useFetch from '../hook/useFetch';
import { C, Card, Avatar } from '../UIKit';
import Loader from '../Loader/Loader';

const ACHIEVEMENTS = [
  { id:1, icon:'🥇', title:'No.1 Active Contributor', desc:'Awarded for consistently engaging and contributing to the platform', color:'#FFD700' },
  { id:2, icon:'🥈', title:'No.2 Feedback Champion', desc:'Awarded for consistently receiving glowing feedback from skill exchange partners', color:'#C0C0C0' },
  { id:3, icon:'🥉', title:'No.3 Task Tackler', desc:'Awarded for completing a total of 15tasks within a month', color:'#CD7F32' },
  { id:4, icon:'🏅', title:'No.1 Connection Champion', desc:'Awarded for consistent engagement with every connections', color:'#FFD700' },
];

export default function Progress() {
  const { user_id, username, token } = useAuth();
  const { data: stats, loading } = useFetch({ url: user_id ? `/api/requests/stats/${user_id}` : null });
  const { data: skillData }      = useFetch({ url: user_id ? `/api/skills/user/${user_id}` : null });

  const STATS = [
    { icon:'🏆', label:'Badges earned', value: Math.min(16, (stats?.accepted||0)*2) },
    { icon:'🤝', label:'Exchanges',      value: stats?.accepted||0 },
    { icon:'📜', label:'Certificates',   value: Math.floor((stats?.accepted||0)/3) },
    { icon:'📚', label:'Courses',        value: skillData?.results?.length||0 },
  ];

  // Fake weekly progress data
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const hrs   = [1.5, 2.2, 1.8, 2.8, 3.1, 2.0, 1.2];
  const maxH  = Math.max(...hrs);

  return (
    <div className="page-enter page-content" style={{ background:C.bg, minHeight:'100vh', padding:'24px 20px' }}>
      <div style={{ maxWidth:'700px', margin:'0 auto' }}>

        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', gap:'16px', marginBottom:'24px' }}>
          <div>
            <h2 style={{ fontWeight:'800', fontSize:'22px', color:C.text }}>Your progress</h2>
          </div>
        </div>

        {/* Profile card */}
        <Card style={{ padding:'20px', marginBottom:'20px', display:'flex', alignItems:'center', gap:'16px' }}>
          <Avatar name={username} size={56} />
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:'6px', marginBottom:'2px' }}>
              <p style={{ fontWeight:'800', fontSize:'18px', color:C.text }}>{username}</p>
              <span style={{ fontSize:'18px' }}>👑</span>
            </div>
            <p style={{ color:C.textMid, fontSize:'13px' }}>Hyderabad, India</p>
          </div>
        </Card>

        {/* Learning time progress chart */}
        <Card style={{ padding:'20px', marginBottom:'20px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <p style={{ fontWeight:'700', color:C.text }}>Learning time progress ⓘ</p>
            <select style={{ border:`1px solid ${C.border}`, borderRadius:'8px', padding:'4px 8px',
              fontSize:'12px', fontFamily:'inherit', outline:'none' }}>
              <option>This Week</option>
              <option>This Month</option>
            </select>
          </div>
          {/* Simple bar chart */}
          <div style={{ display:'flex', alignItems:'flex-end', gap:'8px', height:'80px', marginBottom:'8px' }}>
            {hrs.map((h,i)=>(
              <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:'4px' }}>
                <div style={{ width:'100%', borderRadius:'4px 4px 0 0',
                  background: i===4?C.blue:`${C.blue}40`,
                  height:`${(h/maxH)*68}px`, transition:'height 0.5s ease', position:'relative' }}>
                  {i===4 && <div style={{ position:'absolute', top:'-20px', left:'50%', transform:'translateX(-50%)',
                    background:C.blue, color:'white', borderRadius:'6px', padding:'2px 6px', fontSize:'10px', fontWeight:'700', whiteSpace:'nowrap' }}>
                    {h}h
                  </div>}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display:'flex', gap:'8px' }}>
            {days.map((d,i)=>(
              <div key={d} style={{ flex:1, textAlign:'center', fontSize:'11px',
                color:i===4?C.blue:C.textLight, fontWeight:i===4?'700':'400' }}>{d}</div>
            ))}
          </div>
        </Card>

        {/* Statistics */}
        <Card style={{ padding:'20px', marginBottom:'20px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <p style={{ fontWeight:'700', color:C.text }}>Statistics</p>
            <button style={{ background:'none', border:'none', color:C.blue, fontSize:'13px', fontWeight:'600', cursor:'pointer' }}>View all ›</button>
          </div>
          {loading ? <Loader /> : (
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
              {STATS.map((s,i)=>(
                <div key={i} style={{ background:C.bg, borderRadius:'12px', padding:'14px 16px',
                  display:'flex', alignItems:'center', gap:'10px' }}>
                  <span style={{ fontSize:'22px' }}>{s.icon}</span>
                  <div>
                    <p style={{ fontWeight:'800', fontSize:'20px', color:C.text }}>{s.value}</p>
                    <p style={{ fontSize:'12px', color:C.textMid }}>{s.label}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Achievements */}
        <Card style={{ padding:'20px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
            <p style={{ fontWeight:'700', color:C.text }}>Achievements</p>
            <button style={{ background:'none', border:'none', color:C.blue, fontSize:'13px', fontWeight:'600', cursor:'pointer' }}>View all ›</button>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
            {ACHIEVEMENTS.map(a=>(
              <div key={a.id} style={{ background:C.bg, borderRadius:'14px', padding:'16px',
                display:'flex', flexDirection:'column', alignItems:'center', gap:'8px', textAlign:'center' }}>
                <div style={{ fontSize:'40px', filter:'drop-shadow(0 2px 4px rgba(0,0,0,0.15))' }}>{a.icon}</div>
                <p style={{ fontWeight:'700', fontSize:'13px', color:C.text, lineHeight:'1.3' }}>{a.title}</p>
                <p style={{ fontSize:'11px', color:C.textMid, lineHeight:'1.4' }}>{a.desc}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
