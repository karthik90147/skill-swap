import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Btn, C } from '../UIKit';
import { Search } from 'lucide-react';

const ALL_SKILLS = [
  'Technology','Creativity','Music','DIY','Lifestyle','Health & Fitness','Language',
  'Business','Academics','Photography','Hobbies & Interests','Fashion','Gym',
  'Cooking','Video Editing','Yoga','Coding','UI/UX','Dance',
  'Painting','Gaming','Programming','Gardening','Exercise','Design','Writing',
];

export default function Onboarding() {
  const [step, setStep]             = useState(1);
  const [learnSkills, setLearnSkills] = useState([]);
  const [offerSkills, setOfferSkills] = useState([]);
  const [search, setSearch]         = useState('');
  const [saving, setSaving]         = useState(false);
  const { token } = useAuth();
  const navigate  = useNavigate();

  const filtered = ALL_SKILLS.filter(s => s.toLowerCase().includes(search.toLowerCase()));

  function toggle(skill, type) {
    if (type === 'learn') {
      setLearnSkills(p => p.includes(skill) ? p.filter(s=>s!==skill) : [...p, skill]);
    } else {
      setOfferSkills(p => p.includes(skill) ? p.filter(s=>s!==skill) : [...p, skill]);
    }
  }

  async function finish() {
    setSaving(true);
    // Add offered skills to profile
    for (const skill of offerSkills) {
      try {
        await fetch('/api/skills', { method:'POST',
          headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
          body: JSON.stringify({ name: skill, category: 'Other' }) });
      } catch {}
    }
    navigate('/');
  }

  const currentSkills = step === 1 ? learnSkills : offerSkills;
  const setCurrentSkills = step === 1 ? setLearnSkills : setOfferSkills;

  return (
    <div style={{ minHeight:'100vh', background:C.white, display:'flex', flexDirection:'column', alignItems:'center', padding:'0' }}>
      {/* Header */}
      <div style={{ width:'100%', maxWidth:'480px', padding:'24px 24px 0' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' }}>
          <span style={{ fontSize:'13px', fontWeight:'600', color:C.blue }}>Step {step}/2</span>
          <button onClick={()=>navigate('/')} style={{ background:'none', border:'none',
            color:C.textMid, fontSize:'13px', cursor:'pointer', fontWeight:'600' }}>Skip →</button>
        </div>

        {/* Progress bar */}
        <div style={{ height:'4px', borderRadius:'99px', background:C.blueLight, marginBottom:'28px' }}>
          <div style={{ height:'100%', borderRadius:'99px', background:C.blue, width:step===1?'50%':'100%', transition:'width 0.4s ease' }} />
        </div>

        <h2 style={{ fontWeight:'700', fontSize:'22px', color:C.text, marginBottom:'6px' }}>
          {step === 1 ? 'What skills are you interested in learning?' : 'What skills can you offer to share?'}
        </h2>
        <p style={{ color:C.textMid, fontSize:'13px', marginBottom:'20px' }}>You can customize this at any time.</p>

        {/* Search */}
        <div style={{ position:'relative', marginBottom:'20px' }}>
          <Search size={16} style={{ position:'absolute', left:'14px', top:'50%', transform:'translateY(-50%)', color:C.textLight }} />
          <input placeholder="Find out more" value={search} onChange={e=>setSearch(e.target.value)}
            style={{ width:'100%', padding:'11px 14px 11px 38px', border:`1.5px solid ${C.border}`,
              borderRadius:'12px', fontSize:'14px', outline:'none', fontFamily:'inherit' }}
            onFocus={e=>e.target.style.borderColor=C.blue}
            onBlur={e=>e.target.style.borderColor=C.border} />
        </div>

        {/* Skills grid */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:'8px', maxHeight:'380px', overflowY:'auto', paddingBottom:'8px' }}>
          {filtered.map(skill => {
            const active = currentSkills.includes(skill);
            return (
              <button key={skill} onClick={()=>toggle(skill, step===1?'learn':'offer')}
                className={`skill-pill${active?' active':''}`}>
                {skill}
              </button>
            );
          })}
        </div>

        {/* Selected count */}
        {currentSkills.length > 0 && (
          <p style={{ color:C.blue, fontSize:'13px', fontWeight:'600', marginTop:'12px' }}>
            {currentSkills.length} selected
          </p>
        )}

        {/* Action button */}
        <div style={{ marginTop:'24px', paddingBottom:'32px' }}>
          {step === 1 ? (
            <Btn onClick={()=>{ setStep(2); setSearch(''); }} fullWidth style={{ padding:'15px' }}>
              Continue →
            </Btn>
          ) : (
            <Btn onClick={finish} disabled={saving} fullWidth style={{ padding:'15px' }}>
              {saving ? 'Saving…' : 'Done ✓'}
            </Btn>
          )}
        </div>
      </div>
    </div>
  );
}
