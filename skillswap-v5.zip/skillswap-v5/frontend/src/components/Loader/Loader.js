import React from 'react';
import { Spinner, C } from '../UIKit';

export default function Loader({ fullPage }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center',
      justifyContent:'center', gap:'12px', ...(fullPage?{height:'60vh'}:{}) }}>
      <Spinner size={36} />
      <p style={{ color:C.textLight, fontSize:'13px' }}>Loading…</p>
    </div>
  );
}
