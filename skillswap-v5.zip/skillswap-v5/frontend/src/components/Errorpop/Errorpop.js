import React from 'react';
import { Modal, Btn, C } from '../UIKit';

export default function Errorpop({ err, open, changencomponent }) {
  return (
    <Modal open={open} onClose={()=>changencomponent(false)} title="⚠️ Something went wrong">
      <p style={{ color:C.textMid, marginBottom:'20px', lineHeight:'1.6' }}>{err}</p>
      <Btn onClick={()=>changencomponent(false)} variant="danger" fullWidth>Close</Btn>
    </Modal>
  );
}
