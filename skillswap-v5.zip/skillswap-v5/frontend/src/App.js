import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './components/context/AuthContext';
import { UserProvider } from './components/context/UserContext';
import { SocketProvider } from './components/context/SocketContext';
import Nav from './components/header/Nav';
import Home from './components/body/Home';
import Search from './components/body/Search';
import Requests from './components/body/Requests';
import Friends from './components/body/Friends';
import Profile from './components/body/Profile';
import Chat from './components/body/Chat';
import Groups from './components/body/Groups';
import Progress from './components/body/Progress';
import Scheduler from './components/body/Scheduler';
import Auth from './components/auth/Auth';
import Onboarding from './components/onboarding/Onboarding';
import './index.css';

function Layout({ children }) {
  return (
    <div style={{ minHeight:'100vh', background:'#F5F7FF' }}>
      <Nav />
      <main>{children}</main>
    </div>
  );
}

function Private({ children }) {
  const { user_id } = useAuth();
  return user_id ? children : <Navigate to="/auth" replace />;
}

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth"        element={<Auth />} />
        <Route path="/onboarding"  element={<Private><Onboarding /></Private>} />
        <Route path="/"            element={<Private><Layout><Home /></Layout></Private>} />
        <Route path="/search"      element={<Private><Layout><Search /></Layout></Private>} />
        <Route path="/req"         element={<Private><Layout><Requests /></Layout></Private>} />
        <Route path="/friendlist"  element={<Private><Layout><Friends /></Layout></Private>} />
        <Route path="/profile"     element={<Private><Layout><Profile /></Layout></Private>} />
        <Route path="/chat"        element={<Private><Layout><Chat /></Layout></Private>} />
        <Route path="/groups"      element={<Private><Layout><Groups /></Layout></Private>} />
        <Route path="/progress"    element={<Private><Layout><Progress /></Layout></Private>} />
        <Route path="/scheduler"   element={<Private><Layout><Scheduler /></Layout></Private>} />
        <Route path="*"            element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <UserProvider>
        <SocketProvider>
          <AppRoutes />
        </SocketProvider>
      </UserProvider>
    </AuthProvider>
  );
}
