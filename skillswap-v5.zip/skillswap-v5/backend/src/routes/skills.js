const express = require('express');
const router = express.Router();
const Skill = require('../models/Skill');
const UserSkill = require('../models/UserSkill');
const { protect } = require('../middleware/auth');

router.get('/', async (req, res) => {
  try {
    const skills = await Skill.find().select('_id name description category');
    res.json({ results: skills.map(s => ({ skill_id: s._id, name: s.name, category: s.category })) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/user/:userId', async (req, res) => {
  try {
    const us = await UserSkill.find({ user: req.params.userId }).populate('skill','name category').populate('user','username');
    res.json({ results: us.map(u => ({ userskill_id: u._id, skill_id: u.skill._id, skill_name: u.skill.name, category: u.skill.category, user_name: u.user.username, rating: u.rating })) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/all-users/:userId', async (req, res) => {
  try {
    const us = await UserSkill.find({ user: { $ne: req.params.userId } }).populate('skill','name category').populate('user','username');
    res.json({ results: us.map(u => ({ skill_id: u.skill._id, skill_name: u.skill.name, category: u.skill.category, username: u.user.username, user_id: u.user._id, rating: u.rating })) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/', protect, async (req, res) => {
  const { name, category } = req.body;
  if (!name) return res.status(400).json({ error: 'Skill name required' });
  try {
    let skill = await Skill.findOne({ name: { $regex: new RegExp(`^${name}$`, 'i') } });
    if (!skill) skill = await Skill.create({ name, category: category || 'Other' });
    const exists = await UserSkill.findOne({ user: req.user._id, skill: skill._id });
    if (exists) return res.status(400).json({ error: 'You already have this skill' });
    await UserSkill.create({ user: req.user._id, skill: skill._id });
    res.status(201).json({ message: 'Skill added', skill_id: skill._id, name: skill.name, category: skill.category });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete('/:userSkillId', protect, async (req, res) => {
  try {
    const deleted = await UserSkill.findOneAndDelete({ _id: req.params.userSkillId, user: req.user._id });
    if (!deleted) return res.status(404).json({ error: 'Skill not found' });
    res.json({ message: 'Skill removed' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
