const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const { protect } = require('../middleware/auth');

// GET /api/messages/:friendId - conversation history
router.get('/:friendId', protect, async (req, res) => {
  try {
    const me = req.user._id;
    const friend = req.params.friendId;
    const messages = await Message.find({
      $or: [{ sender: me, receiver: friend }, { sender: friend, receiver: me }],
    }).sort({ createdAt: 1 }).limit(100).populate('sender','username').populate('receiver','username');
    await Message.updateMany({ sender: friend, receiver: me, read: false }, { read: true });
    res.json({ messages: messages.map(m => ({
      _id: m._id,
      sender_id: m.sender._id,
      sender_name: m.sender.username,
      receiver_id: m.receiver._id,
      text: m.text,
      createdAt: m.createdAt,
      read: m.read,
    }))});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/messages - all conversations
router.get('/', protect, async (req, res) => {
  try {
    const me = req.user._id;
    const messages = await Message.find({ $or: [{ sender: me }, { receiver: me }] })
      .sort({ createdAt: -1 }).populate('sender','username').populate('receiver','username');
    const seen = new Set();
    const conversations = [];
    for (const msg of messages) {
      const partner = msg.sender._id.toString() === me.toString() ? msg.receiver : msg.sender;
      const pid = partner._id.toString();
      if (!seen.has(pid)) {
        seen.add(pid);
        const unread = await Message.countDocuments({ sender: partner._id, receiver: me, read: false });
        conversations.push({ partner_id: partner._id, partner_name: partner.username, last_message: msg.text, last_time: msg.createdAt, unread });
      }
    }
    res.json({ conversations });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
