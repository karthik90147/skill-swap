const express = require('express');
const router  = express.Router();
const Group   = require('../models/Group');
const { protect } = require('../middleware/auth');

// GET all groups
router.get('/', async (req, res) => {
  try {
    const groups = await Group.find().populate('creator','username').populate('members','username');
    res.json({ groups });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET my groups
router.get('/mine', protect, async (req, res) => {
  try {
    const groups = await Group.find({ members: req.user._id }).populate('creator','username');
    res.json({ groups });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST create group
router.post('/', protect, async (req, res) => {
  const { name, description, category } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });
  try {
    const group = await Group.create({ name, description, category: category||'Other', creator: req.user._id, members: [req.user._id] });
    res.status(201).json({ message: 'Group created', group });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST join group
router.post('/:id/join', protect, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ error: 'Group not found' });
    if (!group.members.includes(req.user._id)) {
      group.members.push(req.user._id);
      await group.save();
    }
    res.json({ message: 'Joined group' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST leave group
router.post('/:id/leave', protect, async (req, res) => {
  try {
    await Group.findByIdAndUpdate(req.params.id, { $pull: { members: req.user._id } });
    res.json({ message: 'Left group' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
