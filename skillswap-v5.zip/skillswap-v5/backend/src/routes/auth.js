const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const genToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' });

router.post('/signup', async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) return res.status(400).json({ error: 'Fill all fields' });
  try {
    const exists = await User.findOne({ $or: [{ email }, { username }] });
    if (exists) return res.status(400).json({ error: 'Username or email already exists' });
    const user = await User.create({ username, email, password });
    res.status(201).json({ message: 'User created', user_id: user._id, username: user.username, token: genToken(user._id) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/login', async (req, res) => {
  const { emailOrUsername, password } = req.body;
  if (!emailOrUsername || !password) return res.status(400).json({ error: 'Fill all fields' });
  try {
    const user = await User.findOne({ $or: [{ email: emailOrUsername }, { username: emailOrUsername }] });
    if (!user || !(await user.matchPassword(password))) return res.status(401).json({ isCorrectPassword: false, error: 'Invalid credentials' });
    res.json({ isCorrectPassword: true, user_id: user._id, username: user.username, token: genToken(user._id) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
