const express  = require('express');
const router   = express.Router();
const Feedback = require('../models/Feedback');
const { protect } = require('../middleware/auth');

// POST submit feedback
router.post('/', protect, async (req, res) => {
  const { to, rating, comment, emoji } = req.body;
  if (!to || !rating) return res.status(400).json({ error: 'to and rating are required' });
  try {
    const fb = await Feedback.create({ from: req.user._id, to, rating, comment: comment||'', emoji: emoji||'😊' });
    res.status(201).json({ message: 'Feedback submitted', feedback: fb });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET feedback received by a user
router.get('/user/:userId', async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ to: req.params.userId }).populate('from','username');
    const avg = feedbacks.length ? (feedbacks.reduce((s,f)=>s+f.rating,0)/feedbacks.length).toFixed(1) : 0;
    res.json({ feedbacks, average: avg, count: feedbacks.length });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
