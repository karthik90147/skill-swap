const express = require('express');
const router = express.Router();
const Notification = require('../models/Notification');
const { protect } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  try {
    const notifs = await Notification.find({ user: req.user._id }).populate('fromUser','username').sort({ createdAt: -1 }).limit(20);
    res.json({ notifications: notifs });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/unread-count', protect, async (req, res) => {
  try {
    const count = await Notification.countDocuments({ user: req.user._id, read: false });
    res.json({ count });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/mark-all-read', protect, async (req, res) => {
  try {
    await Notification.updateMany({ user: req.user._id, read: false }, { read: true });
    res.json({ message: 'All read' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
