const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const UserSkill = require('../models/UserSkill');
const Notification = require('../models/Notification');
const { protect } = require('../middleware/auth');

router.get('/received/:userId', async (req, res) => {
  try {
    const reqs = await Request.find({ receiver: req.params.userId, status: 'pending' })
      .populate('requester','username').populate('skill','name category');
    res.json({ results: reqs.map(r => ({ request_id: r._id, requester_id: r.requester._id, requester_name: r.requester.username, requester_skills: r.skill.name, skill_id: r.skill._id, category: r.skill.category, message: r.message, type: r.type })) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/friends/:userId', async (req, res) => {
  try {
    const reqs = await Request.find({ $or: [{ receiver: req.params.userId }, { requester: req.params.userId }], status: 'accepted' })
      .populate('requester','username').populate('receiver','username').populate('skill','name category');
    const results = reqs.map(r => {
      const isSender = r.requester._id.toString() === req.params.userId;
      const friend = isSender ? r.receiver : r.requester;
      return { request_id: r._id, requester_id: friend._id, requester_name: friend.username, requester_skills: r.skill.name, skill_id: r.skill._id, category: r.skill.category, message: r.message, type: r.type };
    });
    res.json({ results });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/stats/:userId', async (req, res) => {
  try {
    const uid = req.params.userId;
    const [totalSent, totalReceived, accepted, pending, skillCount] = await Promise.all([
      Request.countDocuments({ requester: uid }),
      Request.countDocuments({ receiver: uid }),
      Request.countDocuments({ $or: [{ receiver: uid }, { requester: uid }], status: 'accepted' }),
      Request.countDocuments({ receiver: uid, status: 'pending' }),
      UserSkill.countDocuments({ user: uid }),
    ]);
    res.json({ totalSent, totalReceived, accepted, pending, skillCount });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/', protect, async (req, res) => {
  const { receiver_id, skill_id, message, type } = req.body;
  if (!receiver_id || !skill_id) return res.status(400).json({ error: 'receiver_id and skill_id required' });
  try {
    const exists = await Request.findOne({ requester: req.user._id, receiver: receiver_id, skill: skill_id, status: 'pending' });
    if (exists) return res.status(400).json({ error: 'Request already sent' });
    const request = await Request.create({ requester: req.user._id, receiver: receiver_id, skill: skill_id, message: message || '', type: type || 'swap' });
    const notifMsg = type === 'learnTogether'
      ? `${req.user.username} wants to learn ${req.body.skillName || 'a skill'} together with you!`
      : `${req.user.username} sent you a skill swap request`;
    await Notification.create({ user: receiver_id, type: type === 'learnTogether' ? 'learn_together' : 'request_received', message: notifMsg, fromUser: req.user._id });
    res.status(201).json({ message: 'Request sent', request_id: request._id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/respond', protect, async (req, res) => {
  const { request_id, status, requester_id, skill_id, rating } = req.body;
  try {
    const request = await Request.findOneAndUpdate({ _id: request_id, receiver: req.user._id }, { status }, { new: true });
    if (!request) return res.status(404).json({ error: 'Request not found' });
    await Notification.create({ user: requester_id || request.requester, type: status === 'accepted' ? 'request_accepted' : 'request_rejected', message: `${req.user.username} ${status} your request`, fromUser: req.user._id });
    if (status === 'accepted' && rating !== undefined) {
      const us = await UserSkill.findOne({ user: requester_id || request.requester, skill: skill_id || request.skill });
      if (us) {
        const newCount = us.ratingCount + 1;
        us.rating = Math.round(((us.rating * us.ratingCount) + rating) / newCount * 10) / 10;
        us.ratingCount = newCount;
        await us.save();
      }
    }
    res.json({ message: `Request ${status}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
