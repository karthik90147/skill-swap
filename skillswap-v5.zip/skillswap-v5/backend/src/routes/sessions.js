const express = require('express');
const router  = express.Router();
const Session = require('../models/Session');
const { protect } = require('../middleware/auth');

// GET my sessions
router.get('/', protect, async (req, res) => {
  try {
    const sessions = await Session.find({
      $or: [{ host: req.user._id }, { participant: req.user._id }],
    }).populate('host','username').populate('participant','username').sort({ date: 1 });
    res.json({ sessions });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST create session
router.post('/', protect, async (req, res) => {
  const { participant_id, title, skill, date, startTime, endTime, notes } = req.body;
  if (!participant_id || !title || !date || !startTime || !endTime)
    return res.status(400).json({ error: 'Fill all required fields' });
  try {
    const session = await Session.create({
      host: req.user._id, participant: participant_id,
      title, skill, date, startTime, endTime, notes: notes||'',
    });
    await session.populate('host','username');
    await session.populate('participant','username');
    res.status(201).json({ message: 'Session scheduled', session });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT update status
router.put('/:id', protect, async (req, res) => {
  try {
    const session = await Session.findOneAndUpdate(
      { _id: req.params.id, $or: [{ host: req.user._id }, { participant: req.user._id }] },
      { status: req.body.status },
      { new: true }
    );
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json({ message: 'Session updated', session });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
