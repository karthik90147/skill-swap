const mongoose = require('mongoose');

const CATEGORIES = ['Programming','Design','Marketing','Music','Language','Finance','Writing','Photography','Cooking','Fitness','Other'];

const skillSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  category:    { type: String, enum: CATEGORIES, default: 'Other' },
}, { timestamps: true });

module.exports = mongoose.model('Skill', skillSchema);
module.exports.CATEGORIES = CATEGORIES;
