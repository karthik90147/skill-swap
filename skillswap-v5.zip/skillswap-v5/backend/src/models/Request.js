const mongoose = require('mongoose');

const requestSchema = new mongoose.Schema({
  requester: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  receiver:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  skill:     { type: mongoose.Schema.Types.ObjectId, ref: 'Skill', required: true },
  message:   { type: String, default: '' },
  type:      { type: String, enum: ['swap', 'learnTogether'], default: 'swap' },
  status:    { type: String, enum: ['pending', 'accepted', 'rejected'], default: 'pending' },
}, { timestamps: true });

module.exports = mongoose.model('Request', requestSchema);
