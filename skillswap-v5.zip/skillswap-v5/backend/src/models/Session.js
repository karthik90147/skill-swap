const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
  host:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  participant: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title:       { type: String, required: true },
  skill:       { type: String, default: '' },
  date:        { type: Date, required: true },
  startTime:   { type: String, required: true },
  endTime:     { type: String, required: true },
  status:      { type: String, enum: ['scheduled', 'completed', 'cancelled'], default: 'scheduled' },
  notes:       { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Session', sessionSchema);
