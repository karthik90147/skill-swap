const express = require('express');
const cors    = require('cors');
const dotenv  = require('dotenv');
const http    = require('http');
const { Server } = require('socket.io');
const jwt     = require('jsonwebtoken');
const connectDB = require('./config/db');
const Message   = require('./models/Message');

dotenv.config();
connectDB();

const app    = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: ['http://localhost:3000','http://127.0.0.1:3000'], methods:['GET','POST'], credentials:true },
  transports: ['websocket','polling'],
});

app.use(cors({ origin:['http://localhost:3000','http://127.0.0.1:3000'], credentials:true }));
app.use(express.json());

app.use('/api/auth',          require('./routes/auth'));
app.use('/api/skills',        require('./routes/skills'));
app.use('/api/requests',      require('./routes/requests'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/messages',      require('./routes/messages'));
app.use('/api/groups',        require('./routes/groups'));
app.use('/api/sessions',      require('./routes/sessions'));
app.use('/api/feedback',      require('./routes/feedback'));

app.get('/', (req, res) => res.json({ message: 'SkillSwap API v5' }));

const onlineUsers = new Map();

io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('No token'));
  try { const d = jwt.verify(token, process.env.JWT_SECRET); socket.userId = d.id.toString(); next(); }
  catch { next(new Error('Invalid token')); }
});

io.on('connection', (socket) => {
  const userId = socket.userId;
  onlineUsers.set(userId, socket.id);
  io.emit('online_users', Array.from(onlineUsers.keys()));

  socket.on('send_message', async ({ receiver_id, text }) => {
    if (!text?.trim() || !receiver_id) return;
    try {
      const msg = await Message.create({ sender: userId, receiver: receiver_id, text: text.trim() });
      await msg.populate('sender','username');
      await msg.populate('receiver','username');
      const payload = { _id: msg._id.toString(), sender_id: msg.sender._id.toString(), sender_name: msg.sender.username, receiver_id: msg.receiver._id.toString(), text: msg.text, createdAt: msg.createdAt, read: false };
      const rSock = onlineUsers.get(receiver_id.toString());
      if (rSock) io.to(rSock).emit('receive_message', payload);
      socket.emit('message_sent', payload);
    } catch (err) { socket.emit('message_error', { error: err.message }); }
  });

  socket.on('typing', ({ receiver_id, isTyping }) => {
    const rSock = onlineUsers.get(receiver_id?.toString());
    if (rSock) io.to(rSock).emit('user_typing', { sender_id: userId, isTyping });
  });

  socket.on('disconnect', () => { onlineUsers.delete(userId); io.emit('online_users', Array.from(onlineUsers.keys())); });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
